<?php
session_start();
include 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;

$prep_sql = "SELECT o.id, o.sale_date, o.status, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
             FROM orders o
             JOIN order_queue oq ON o.id = oq.order_id
             JOIN menu_items mi ON oq.menu_item_id = mi.id
             WHERE o.user_id = ? AND o.status IN ('Preparing')
             GROUP BY o.id
             ORDER BY o.sale_date DESC";
$prep_stmt = $conn->prepare($prep_sql);
$prep_stmt->bind_param("i", $user_id);
$prep_stmt->execute();
$preparing_orders = $prep_stmt->get_result();

$ready_sql = "SELECT o.id, o.sale_date, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
              FROM orders o
              JOIN order_queue oq ON o.id = oq.order_id
              JOIN menu_items mi ON oq.menu_item_id = mi.id
              WHERE o.user_id = ? AND o.status = 'Ready'
              GROUP BY o.id
              ORDER BY o.sale_date DESC";
$ready_stmt = $conn->prepare($ready_sql);
$ready_stmt->bind_param("i", $user_id);
$ready_stmt->execute();
$ready_orders = $ready_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Queue Status</title>
    <style>
    @keyframes fadeUp {
      0% {
        opacity: 0;
        transform: translateY(20px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f9f9f9;
      margin: 0;
      padding: 40px 20px;
      color: #333;
      display: flex;
      justify-content: center;
    }

    .container {
      max-width: 900px;
      width: 100%;
      animation: fadeUp 0.6s ease;
    }

    a {
      text-decoration: none;
      color: #0077cc;
      font-weight: bold;
      display: inline-block;
      margin-bottom: 20px;
    }

    h2 {
      font-size: 1.5rem;
      margin-top: 40px;
      margin-bottom: 10px;
    }

    .card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      padding: 20px;
      margin-bottom: 30px;
      animation: fadeUp 0.6s ease;
    }

    .order-table {
      width: 100%;
      border-collapse: collapse;
    }

    .order-table th,
    .order-table td {
      padding: 12px 10px;
      text-align: left;
      vertical-align: top;
    }

    .order-table th {
      background-color: #f1f1f1;
      font-weight: 600;
    }

    .order-table tr:not(:last-child) {
      border-bottom: 1px solid #eee;
    }

    .no-orders {
      font-style: italic;
      color: #777;
    }

    button {
      background: #4CAF50;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: background 0.2s;
    }

    button:hover {
      background: #43a047;
    }

    .section-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.2rem;
      margin-bottom: 10px;
    }

    .section-title span {
      font-size: 1.3rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="index.php">← Back to Menu</a>

    <div class="card">
      <div class="section-title"><span>🧑‍🍳</span> Preparing Orders</div>
      <?php if ($preparing_orders->num_rows > 0): ?>
        <table class="order-table">
          <tr>
            <th>Order #</th>
            <th>Date</th>
            <th>Status</th>
            <th>Items</th>
          </tr>
          <?php while ($row = $preparing_orders->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= $row['sale_date'] ?></td>
              <td><?= $row['status'] ?></td>
              <td><?= $row['items'] ?></td>
            </tr>
          <?php endwhile; ?>
        </table>
      <?php else: ?>
        <p class="no-orders">No preparing orders.</p>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="section-title"><span>✅</span> Ready to Serve</div>
      <?php if ($ready_orders->num_rows > 0): ?>
        <table class="order-table">
          <tr>
            <th>Order #</th>
            <th>Date</th>
            <th>Items</th>
            <th>Action</th>
          </tr>
          <?php while ($row = $ready_orders->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= $row['sale_date'] ?></td>
              <td><?= $row['items'] ?></td>
              <td>
                <form method="POST" action="complete_order.php" style="display:inline;">
                  <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                  <button type="submit" onclick="return confirm('Mark this order as completed?');">
                    ✅ Complete
                  </button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        </table>
      <?php else: ?>
        <p class="no-orders">No ready orders yet.</p>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
