<?php
session_start();
include 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;

// Fetch menu items
$sql = "SELECT * FROM menu_items WHERE status = 'active' AND is_active = 1 ORDER BY sales_count DESC";
$menuItems = $conn->query($sql);

// Fetch cart items
$cart_stmt = $conn->prepare("SELECT c.id AS cart_id, m.name, m.price, c.quantity, (m.price * c.quantity) AS total 
                             FROM cart c JOIN menu_items m ON c.menu_item_id = m.id 
                             WHERE c.user_id = ?");
$cart_stmt->bind_param("i", $user_id);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

$cart_items = [];
$grand_total = 0;
while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $grand_total += $row['total'];
}
// Fetch Preparing orders
$prep_sql = "SELECT o.id, o.sale_date, o.status, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
             FROM orders o
             JOIN order_queue oq ON o.id = oq.order_id
             JOIN menu_items mi ON oq.menu_item_id = mi.id
             WHERE o.status IN ('Preparing')
             GROUP BY o.id
             ORDER BY o.sale_date DESC";
$prep_stmt = $conn->prepare($prep_sql);
$prep_stmt->execute();
$preparing_orders = $prep_stmt->get_result();

// Fetch Ready orders
$ready_sql = "SELECT o.id, o.sale_date, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
              FROM orders o
              JOIN order_queue oq ON o.id = oq.order_id
              JOIN menu_items mi ON oq.menu_item_id = mi.id
              WHERE o.status = 'Ready'
              GROUP BY o.id
              ORDER BY o.sale_date DESC";
$ready_stmt = $conn->prepare($ready_sql);
$ready_stmt->execute();
$ready_orders = $ready_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>The Burgis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #fcf5ed;
        }

        .navbar {
            background-color: #2f6907;
            padding: 15px 30px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-right a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
        }

        .menu-title {
            text-align: center;
            margin: 30px 0 10px;
            color: #d73745;
            font-size: 28px;
            font-weight: bold;
        }

        .scroll-wrapper {
            position: relative;
            padding: 0 40px;
        }

        .scroll-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            background-color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            z-index: 2;
        }

        .scroll-btn.left {
            left: 0;
        }

        .scroll-btn.right {
            right: 0;
        }

        .menu-container {
            display: flex;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            gap: 20px;
            padding: 10px 20px 40px;
            scroll-behavior: smooth;
        }

        .menu-container::-webkit-scrollbar {
            height: 8px;
        }

        .menu-container::-webkit-scrollbar-thumb {
            background: #ccc;
            border-radius: 10px;
        }

        .card {
            animation: slideInUp 0.5s ease both;
            width: 100%;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 15px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.03);
        }

        .card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .price {
            font-weight: bold;
            margin: 8px 0;
            color: #333;
        }

        .out-of-stock {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }

        input[type="number"] {
            width: 60px;
            padding: 4px;
            margin-right: 5px;
        }

        button {
            padding: 6px 12px;
            background-color: #28a745;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        button:disabled {
            background-color: gray;
            cursor: not-allowed;
        }

        .toast-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1055;
        }

        .modal-body {
            padding: 25px;
        }

        .modal-footer {
            padding: 20px 25px;
        }

        @keyframes slideInUp {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }

            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.06);
            }

            100% {
                transform: scale(1);
            }
        }

        @keyframes popIn {
            0% {
                opacity: 0;
                transform: scale(0.85);
            }

            100% {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Apply animation to menu cards */
        .card {
            animation: slideInUp 0.5s ease both;
        }

        /* Toast fade-in */
        .toast {
            animation: fadeIn 0.6s ease;
        }

        /* Pulse effect on View Cart */
        .navbar-right a[data-bs-target="#cartModal"] {
            animation: pulse 1.6s ease-in-out infinite;
        }

        /* Modal pop-in effect */
        .modal-content {
            animation: popIn 0.4s ease;
        }
    </style>
</head>

<body>

    <div class="navbar">
        <div class="navbar-left" style="cursor:pointer;" onclick="window.location.href='login.php';"><i class="fa-solid fa-burger me-2"></i> THE BURGIS</div>
        <div class="navbar-right">
            <a href="#" data-bs-toggle="modal" data-bs-target="#cartModal"><i
                    class="fa-solid fa-cart-shopping me-1"></i> View Cart</a>
            <a href="#" data-bs-toggle="modal" data-bs-target="#readyOrdersModal">
                <i class="fa-solid fa-check me-1"></i> Ready to Serve</a>
        </div>
    </div>

    <div class="menu-title"><i class="fa-solid fa-utensils me-2"></i>Menu</div>




    <div class="container">
        <div class="row" id="menuScroll">
            <?php while ($row = $menuItems->fetch_assoc()): ?>
                <div class="col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="card h-100">
                        <img class="card-img-top"
                            src="<?= !empty($row['image']) && file_exists($row['image']) ? htmlspecialchars($row['image']) : 'placeholder.jpg' ?>"
                            alt="<?= htmlspecialchars($row['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($row['description']) ?></p>
                            <p class="price mb-2">₱<?= number_format($row['price'], 2) ?></p>
                            <?php
                            // Ingredient stock check (same as before)
                            $can_make = true;
                            $max_servings = PHP_INT_MAX;
                            $recipe_stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
                            $recipe_stmt->bind_param("i", $row['id']);
                            $recipe_stmt->execute();
                            $recipe_result = $recipe_stmt->get_result();
                            if ($recipe_result->num_rows == 0) {
                                $can_make = false;
                            }
                            while ($ingredient = $recipe_result->fetch_assoc()) {
                                $ing_id = $ingredient['ingredient_id'];
                                $qty_needed = $ingredient['quantity_needed'];
                                if ($qty_needed <= 0)
                                    continue;
                                $ing_stock_result = $conn->query("SELECT stock FROM ingredients WHERE id = $ing_id");
                                $ing_stock = $ing_stock_result->fetch_assoc()['stock'] ?? 0;
                                if ($ing_stock < $qty_needed) {
                                    $can_make = false;
                                    break;
                                }
                                $possible_servings = intdiv($ing_stock, $qty_needed);
                                if ($possible_servings < $max_servings) {
                                    $max_servings = $possible_servings;
                                }
                            }
                            ?>
                            <?php if ($can_make && $max_servings > 0): ?>
                                <form onsubmit="return addToCart(event, <?= $row['id'] ?>, this.quantity.value)"
                                    class="mt-auto">
                                    <label>Qty:</label>
                                    <input type="number" name="quantity" value="1" min="1" max="<?= $max_servings ?>" required
                                        class="form-control mb-2">
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fa-solid fa-cart-plus me-2"></i>Add to Cart
                                    </button>
                                </form>
                            <?php else: ?>
                                <div class="out-of-stock text-danger mt-auto">Out of Stock</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>





    <!-- Toast -->
    <div class="toast-container">
        <div id="addedToast" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fa-solid fa-check-circle me-2"></i>Item added to cart!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Cart Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">

            <div class="modal-content">
                <form action="actions/checkout.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fa-solid fa-cart-shopping me-2"></i>Your Cart</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="cartModalBody">
                        <!-- Cart items will be loaded here via AJAX -->
                    </div>
                    <div class="modal-footer" id="cartModalFooter">
                        <!-- The checkout button will be loaded via AJAX as well -->
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ✅ READY ORDERS MODAL -->
    <div class="modal fade" id="readyOrdersModal" tabindex="-1" aria-labelledby="readyOrdersLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">🧾 Order Queue Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 25px;">
                    <h5>🧑‍🍳 Preparing Orders</h5>
                    <?php if ($preparing_orders->num_rows > 0): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Items</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $preparing_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= $row['sale_date'] ?></td>
                                        <td><?= $row['status'] ?></td>
                                        <td><?= $row['items'] ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-muted">No preparing orders.</p>
                    <?php endif; ?>

                    <hr>

                    <h5>✅ Ready to Serve</h5>
                    <?php if ($ready_orders->num_rows > 0): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Date</th>
                                    <th>Items</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $ready_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= $row['sale_date'] ?></td>
                                        <td><?= $row['items'] ?></td>
                                        <td>
                                            <form method="POST" action="complete_order.php"
                                                onsubmit="return confirm('Mark this order as completed?');">
                                                <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                                                <button type="submit" class="btn btn-success btn-sm">✅ Complete</button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-muted">No ready orders yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function scrollMenu(direction) {
            const container = document.getElementById('menuScroll');
            const scrollAmount = 300;
            container.scrollLeft += direction === 'left' ? -scrollAmount : scrollAmount;
        }

        function loadCartModal() {
            fetch('actions/cart_modal_update.php')
                .then(res => res.text())
                .then(html => {
                    // Split the returned HTML into body and footer if needed
                    // For simplicity, assume all content goes into modal body
                    document.getElementById('cartModalBody').innerHTML = html;

                    // If you want to move the checkout button to the footer, you can split it out in cart_modal.php
                    // Or, keep everything in the body for now
                });
        }

        // Load cart modal content every time the modal is shown
        document.addEventListener('DOMContentLoaded', function () {
            refreshMenu();

            // Show toast if needed
            if (localStorage.getItem('showToast') === '1') {
                setTimeout(() => {
                    const toast = new bootstrap.Toast(document.getElementById('addedToast'));
                    toast.show();
                    localStorage.removeItem('showToast');
                }, 300);
            }

            // Bootstrap 5 event for showing modal
            var cartModal = document.getElementById('cartModal');
            cartModal.addEventListener('show.bs.modal', function () {
                loadCartModal();
            });
        });

        function removeFromCart(cartId) {
            const cashInput = document.getElementById('cash');
            let currentCash = cashInput ? cashInput.value : '';

            fetch(`actions/remove_from_cart.php?id=${cartId}`)
                .then(res => res.json())
                .then(() => {
                    loadCartModal();
                    refreshMenu();
                })
                .catch(err => console.error("Error updating cart:", err));
        }

        function refreshMenu() {
            fetch('actions/menu_update.php')
                .then(res => res.text())
                .then(html => {
                    document.getElementById('menuScroll').innerHTML = html;
                });
        }

        function calculateChange() {
            const total = parseFloat(document.getElementById('grand_total')?.value) || 0;
            const cashInput = document.getElementById('cash');
            let cash = parseFloat(cashInput?.value);

            if (isNaN(cash) || cash < 0) cash = 0;

            let change = cash - total;
            const display = document.getElementById('change');
            display.innerText = 'Change: ₱' + Math.max(change, 0).toFixed(2);
        }
        // Handle order completion without page reload
        document.addEventListener('click', function (e) {
            if (e.target && e.target.classList.contains('complete-btn')) {
                e.preventDefault();

                const btn = e.target;
                const orderId = btn.dataset.orderId;

                if (!confirm("Mark this order as completed?")) return;

                fetch('complete_order.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'order_id=' + encodeURIComponent(orderId)
                })
                    .then(res => res.text())
                    .then(() => {
                        // Remove the row from the table or reload part of modal
                        const row = btn.closest('tr');
                        row.remove();
                    })
                    .catch(err => console.error("Failed to complete order:", err));
            }
        });
        function addToCart(event, itemId, quantity) {
            event.preventDefault();

            const formData = new FormData();
            formData.append('menu_item_id', itemId);
            formData.append('quantity', quantity);

            fetch('actions/add_to_cart.php', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const toast = new bootstrap.Toast(document.getElementById('addedToast'));
                        toast.show();
                        loadCartModal();
                        refreshMenu();
                    } else {
                        alert(data.error === 'ingredient_out_of_stock'
                            ? 'Not enough ingredients to fulfill your order.'
                            : 'Failed to add to cart.');
                    }
                })
                .catch(err => console.error("Add to cart failed:", err));

            return false;
        }
    </script>
    <!-- Receipt Modal -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-labelledby="receiptModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content" id="receiptModalContent">
                <!-- Dynamic content inserted via JS after checkout -->
            </div>
        </div>
    </div>

</body>

</html>