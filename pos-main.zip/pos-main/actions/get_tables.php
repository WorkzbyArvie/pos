<?php
include '../includes/db.php';

$category = $_GET['category'] ?? '';
$datetime = $_GET['datetime'] ?? '';

$tables = [];
if ($category == 'small') $tables = range(1,5);
if ($category == 'medium') $tables = range(6,10);
if ($category == 'large') $tables = range(11,15);

$available = [];

foreach ($tables as $num) {
    // If user already picked datetime, filter by it
    if (!empty($datetime)) {
        $stmt = $conn->prepare("SELECT * FROM reservations 
            WHERE table_number = ? 
            AND reservation_datetime BETWEEN DATE_SUB(?, INTERVAL 1 HOUR) AND DATE_ADD(?, INTERVAL 1 HOUR)");
        $stmt->bind_param("iss", $num, $datetime, $datetime);
    } else {
        // If no datetime yet, just show all tables
        $stmt = $conn->prepare("SELECT * FROM reservations WHERE 1=0");
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        $available[] = $num;
    }
}

header('Content-Type: application/json');
echo json_encode($available);
