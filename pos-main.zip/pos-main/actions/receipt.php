<?php
session_start();
include '../includes/db.php'; // ✅ Corrected path

$order_id = $_GET['order_id'] ?? null;
$cash = $_GET['cash'] ?? 0;

if (!$order_id) {
    echo "Order ID missing.";
    exit;
}

// Get order items
$sql = "SELECT m.name, oq.quantity, m.price, (oq.quantity * m.price) AS total
        FROM order_queue oq
        JOIN menu_items m ON oq.menu_item_id = m.id
        WHERE oq.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
$grand_total = 0;

while ($row = $result->fetch_assoc()) {
    $items[] = $row;
    $grand_total += $row['total'];
}

$change = $cash - $grand_total;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>
    <style>
        body {
            background-color: #fefefe;
            padding: 40px;
        }
        .receipt-card {
            background: white;
            max-width: 450px;
            margin: auto;
            padding: 30px;
            border-radius: 12px;
            border-top: 10px solid #2f6907;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .highlight { color: #2f6907; font-weight: bold; }
        .yellow { color: #ffc700; font-weight: bold; }
        .item-row {
            display: flex;
            justify-content: space-between;
            border-bottom: 1px dashed #ccc;
            padding: 8px 0;
        }
    </style>
</head>
<body>

<div class="receipt-card">
    <h2 class="text-center text-success mb-4">🧾 Payment Receipt</h2>

    <?php foreach ($items as $item): ?>
        <div class="item-row">
            <span><?= htmlspecialchars($item['name']) ?> x<?= $item['quantity'] ?></span>
            <span>₱<?= number_format($item['total'], 2) ?></span>
        </div>
    <?php endforeach; ?>

    <div class="mt-3">
        <p>Total: <span class="highlight">₱<?= number_format($grand_total, 2) ?></span></p>
        <p>Cash: <span class="yellow">₱<?= number_format($cash, 2) ?></span></p>
        <p>Change: <span class="highlight">₱<?= number_format(max($change, 0), 2) ?></span></p>
    </div>

    <div class="text-center mt-4" id="qrcode"></div>

    <div class="text-center mt-3">
        <button class="btn btn-success" onclick="window.print()">🖨 Print Receipt</button>
        <a href="../landing.php" class="btn btn-outline-success mt-2">← Back to Menu</a>
    </div>
</div>

<script>
    const qrText = `Order #<?= $order_id ?>\nTotal: ₱<?= number_format($grand_total, 2) ?>\nCash: ₱<?= number_format($cash, 2) ?>\nChange: ₱<?= number_format($change, 2) ?>\nThank you!`;

    QRCode.toCanvas(document.createElement("canvas"), qrText, { width: 160 }, function (error, canvas) {
        if (!error) {
            document.getElementById("qrcode").appendChild(canvas);
        }
    });
</script>

</body>
</html>
