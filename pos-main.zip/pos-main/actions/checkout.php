<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;

// Fetch cart items
$sql = "SELECT c.*, m.name, m.price FROM cart c JOIN menu_items m ON c.menu_item_id = m.id WHERE c.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result();

$total_price = 0;
$items = [];

while ($item = $cart_items->fetch_assoc()) {
    $subtotal = $item['price'] * $item['quantity'];
    $total_price += $subtotal;
    $items[] = $item;
}

$error = "";
$cash = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cash'])) {
    $cash = floatval($_POST['cash']);

    if ($cash < $total_price) {
        $error = "❌ Insufficient cash. Total is ₱" . number_format($total_price, 2);
    } else {
        // Create order
        $order_stmt = $conn->prepare("INSERT INTO orders (user_id, sale_date, status) VALUES (?, NOW(), 'Queued')");
        $order_stmt->bind_param("i", $user_id);
        $order_stmt->execute();
        $order_id = $order_stmt->insert_id;

        foreach ($items as $item) {
            $menu_item_id = $item['menu_item_id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            $total = $price * $quantity;

            // Insert into sales
            $stmt = $conn->prepare("INSERT INTO sales (user_id, menu_item_id, quantity, total_price, sale_date) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param("iiid", $user_id, $menu_item_id, $quantity, $total);
            $stmt->execute();

            // Insert into order_queue
            $oq_stmt = $conn->prepare("INSERT INTO order_queue (order_id, menu_item_id, quantity) VALUES (?, ?, ?)");
            $oq_stmt->bind_param("iii", $order_id, $menu_item_id, $quantity);
            $oq_stmt->execute();

            // Update stock
            $stmt = $conn->prepare("UPDATE menu_items SET sales_count = sales_count + ? WHERE id = ?");
            $stmt->bind_param("ii", $quantity, $menu_item_id);
            $stmt->execute();
        }

        // Clear cart
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        // Redirect to receipt page
        header("Location: receipt.php?cash=" . urlencode($cash) . "&order_id=" . urlencode($order_id));
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f6f6;
            padding: 30px;
        }

        .container {
            background: white;
            padding: 25px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .total {
            font-size: 22px;
            text-align: center;
            margin: 20px 0;
            color: #444;
        }

        form {
            text-align: center;
        }

        input[type="number"] {
            padding: 8px;
            width: 200px;
            font-size: 16px;
            margin-top: 10px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 8px;
        }

        button {
            margin-top: 15px;
            padding: 10px 20px;
            background: #28a745;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Checkout</h2>

    <div class="total">
        Total Price: ₱<?= number_format($total_price, 2) ?>
    </div>

    <form method="POST">
        <label>Enter Cash Amount:</label><br>
        <input type="number" name="cash" step="0.01" required value="<?= htmlspecialchars($cash) ?>"><br>

        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <button type="submit">Pay Now</button>
    </form>
</div>
</body>
</html>
