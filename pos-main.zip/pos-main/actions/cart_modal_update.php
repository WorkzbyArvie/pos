<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;

$cart_stmt = $conn->prepare("SELECT c.id AS cart_id, m.name, m.price, c.quantity, (m.price * c.quantity) AS total 
                             FROM cart c JOIN menu_items m ON c.menu_item_id = m.id 
                             WHERE c.user_id = ?");
$cart_stmt->bind_param("i", $user_id);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

$cart_items = [];
$grand_total = 0;
while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $grand_total += $row['total'];
}
?>

<?php if (!empty($cart_items)): ?>
    <?php foreach ($cart_items as $item): ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
            <div><i class="fa-solid fa-utensil-spoon me-2 text-secondary"></i><?= htmlspecialchars($item['name']) ?> x
                <?= $item['quantity'] ?></div>
            <div>₱<?= number_format($item['total'], 2) ?></div>
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeFromCart(<?= $item['cart_id'] ?>)">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        </div>
    <?php endforeach; ?>
    <div class="fw-bold my-2">Total: ₱<?= number_format($grand_total, 2) ?></div>
    <input type="hidden" id="grand_total" value="<?= $grand_total ?>">
    <div class="mb-2">
        <label for="cash" class="form-label">Cash Tendered (₱):</label>
        <input type="number" min="0" step="0.01" class="form-control" id="cash" name="cash" placeholder="0"
            oninput="calculateChange()" required>
    </div>
    <div class="fw-bold" id="change">Change: ₱0.00</div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-success"><i class="fa-solid fa-cash-register me-2"></i>Checkout</button>
    </div>
<?php else: ?>
    <p class="text-muted"><i class="fa-solid fa-circle-info me-2"></i>Your cart is empty.</p>
    <div class="modal-footer">
        <button type="submit" class="btn btn-success" disabled><i
                class="fa-solid fa-cash-register me-2"></i>Checkout</button>
    </div>
<?php endif; ?>