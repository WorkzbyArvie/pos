<?php
session_start();
include '../includes/db.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['user_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $category = $_POST['table_category'] ?? '';
    $table_number = $_POST['table_number'] ?? '';
    $datetime = $_POST['reservation_datetime'] ?? '';

    // Check all fields
    if (!$name || !$phone || !$category || !$table_number || !$datetime) {
        $response['message'] = 'All fields are required.';
    }
    // Prevent past reservations
    elseif (strtotime($datetime) < time()) {
        $response['message'] = 'You cannot reserve for past times.';
    } else {
        // Check for conflicts ±1 hour
        $check = $conn->prepare("SELECT * FROM reservations 
            WHERE table_number = ? 
            AND reservation_datetime BETWEEN DATE_SUB(?, INTERVAL 1 HOUR) AND DATE_ADD(?, INTERVAL 1 HOUR)");
        $check->bind_param("iss", $table_number, $datetime, $datetime);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $response['message'] = 'Table not available at this time. Please choose another time or table.';
        } else {
            // Save reservation
            $stmt = $conn->prepare("INSERT INTO reservations (user_name, phone, table_category, table_number, reservation_datetime) 
                                    VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssis", $name, $phone, $category, $table_number, $datetime);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Reservation successful!';
            } else {
                $response['message'] = 'Database error. Please try again.';
            }
        }
    }
}

// Return JSON for in-page handling
header('Content-Type: application/json');
echo json_encode($response);
    