<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;
$cart_id = $_GET['id'] ?? null;

if ($cart_id) {
    // Get menu_item_id and quantity from cart for this user
    $stmt = $conn->prepare("SELECT menu_item_id, quantity FROM cart WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $cart_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $menu_item_id = $row['menu_item_id'];
        $quantity = $row['quantity'];

        // Restore ingredient stock
        $recipe = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
        $recipe->bind_param("i", $menu_item_id);
        $recipe->execute();
        $recipe_result = $recipe->get_result();
        while ($ingredient = $recipe_result->fetch_assoc()) {
            $ingredient_id = $ingredient['ingredient_id'];
            $qty_to_restore = $ingredient['quantity_needed'] * $quantity;
            $update = $conn->prepare("UPDATE ingredients SET stock = stock + ? WHERE id = ?");
            $update->bind_param("ii", $qty_to_restore, $ingredient_id);
            $update->execute();
        }
    }

    // Delete the cart row for this user
    $del = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $del->bind_param("ii", $cart_id, $user_id);
    $del->execute();
}

// Re-fetch updated cart items for this user
$cart_stmt = $conn->prepare("SELECT c.id AS cart_id, m.name, m.price, c.quantity, (m.price * c.quantity) AS total 
                             FROM cart c JOIN menu_items m ON c.menu_item_id = m.id 
                             WHERE c.user_id = ?");
$cart_stmt->bind_param("i", $user_id);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

$cart_items = [];
$grand_total = 0;
while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $grand_total += $row['total'];
}

echo json_encode([
    'items' => $cart_items,
    'total' => $grand_total
]);
exit;


?>