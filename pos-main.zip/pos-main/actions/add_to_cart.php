<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;
$menu_item_id = intval($_POST['menu_item_id'] ?? 0);
$quantity = intval($_POST['quantity'] ?? 1);

if ($menu_item_id <= 0 || $quantity <= 0) {
    echo json_encode(['success' => false, 'error' => 'invalid_input']);
    exit;
}

// 1. Check ingredient stock for the requested quantity
$recipe = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
$recipe->bind_param("i", $menu_item_id);
$recipe->execute();
$recipe_result = $recipe->get_result();

$can_make = true;
$needed_ingredients = [];
while ($row = $recipe_result->fetch_assoc()) {
    $ingredient_id = $row['ingredient_id'];
    $qty_needed = $row['quantity_needed'];
    if ($qty_needed <= 0)
        continue;

    $qty_needed_total = $qty_needed * $quantity;
    $ing_stock_result = $conn->query("SELECT stock FROM ingredients WHERE id = $ingredient_id");
    $ing_stock = $ing_stock_result->fetch_assoc()['stock'] ?? 0;
    if ($ing_stock < $qty_needed_total) {
        $can_make = false;
        break;
    }
    $needed_ingredients[] = ['id' => $ingredient_id, 'qty' => $qty_needed, 'total' => $qty_needed_total];
}

if (!$can_make) {
    echo json_encode(['success' => false, 'error' => 'ingredient_out_of_stock']);
    exit;
}

// 2. Add to cart (insert or update)
$check = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND menu_item_id = ?");
$check->bind_param("ii", $user_id, $menu_item_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    $existing = $result->fetch_assoc();
    $old_qty = $existing['quantity'];
    $new_qty = $existing['quantity'] + $quantity;

    // Check again for ingredient stock for the new total quantity
    $can_make = true;
    foreach ($needed_ingredients as $ing) {
        $ingredient_id = $ing['id'];
        $qty_needed_row = $conn->query("SELECT quantity_needed FROM menu_item_ingredients WHERE menu_item_id = $menu_item_id AND ingredient_id = $ingredient_id")->fetch_assoc();
        $qty_needed = $qty_needed_row['quantity_needed'];
        if ($qty_needed <= 0)
            continue;

        $qty_needed_total = $qty_needed * $new_qty;
        $ing_stock = $conn->query("SELECT stock FROM ingredients WHERE id = $ingredient_id")->fetch_assoc()['stock'] ?? 0;
        if ($ing_stock < $qty_needed_total) {
            $can_make = false;
            break;
        }
    }
    if (!$can_make) {
        echo json_encode(['success' => false, 'error' => 'ingredient_out_of_stock']);
        exit;
    }

    $update = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $update->bind_param("ii", $new_qty, $existing['id']);
    $update->execute();

    // Deduct only the difference
    $diff_qty = $new_qty - $old_qty;
    foreach ($needed_ingredients as $ing) {
        if ($ing['qty'] <= 0)
            continue;
        $deduct = $ing['qty'] * $diff_qty;
        if ($deduct > 0) {
            $update_ing = $conn->prepare("UPDATE ingredients SET stock = stock - ? WHERE id = ?");
            $update_ing->bind_param("ii", $deduct, $ing['id']);
            $update_ing->execute();
        }
    }
} else {
    $insert = $conn->prepare("INSERT INTO cart (user_id, menu_item_id, quantity) VALUES (?, ?, ?)");
    $insert->bind_param("iii", $user_id, $menu_item_id, $quantity);
    $insert->execute();

    // Deduct full quantity
    foreach ($needed_ingredients as $ing) {
        if ($ing['qty'] <= 0)
            continue;
        $deduct = $ing['qty'] * $quantity;
        $update_ing = $conn->prepare("UPDATE ingredients SET stock = stock - ? WHERE id = ?");
        $update_ing->bind_param("ii", $deduct, $ing['id']);
        $update_ing->execute();
    }
}

echo json_encode(['success' => true]);
exit;