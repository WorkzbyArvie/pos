<?php
session_start();
include '../includes/db.php';

$sql = "SELECT * FROM menu_items WHERE status = 'active' AND is_active = 1 ORDER BY sales_count DESC";
$menuItems = $conn->query($sql);

$menu_html = '';

while ($row = $menuItems->fetch_assoc()) {
    $can_make = true;
    $max_servings = PHP_INT_MAX;
    $recipe_stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
    $recipe_stmt->bind_param("i", $row['id']);
    $recipe_stmt->execute();
    $recipe_result = $recipe_stmt->get_result();
    if ($recipe_result->num_rows == 0) {
        $can_make = false;
    }
    while ($ingredient = $recipe_result->fetch_assoc()) {
        $ing_id = $ingredient['ingredient_id'];
        $qty_needed = $ingredient['quantity_needed'];
        if ($qty_needed <= 0)
            continue;
        $ing_stock_result = $conn->query("SELECT stock FROM ingredients WHERE id = $ing_id");
        $ing_stock = $ing_stock_result->fetch_assoc()['stock'] ?? 0;
        if ($ing_stock < $qty_needed) {
            $can_make = false;
            break;
        }
        $possible_servings = intdiv($ing_stock, $qty_needed);
        if ($possible_servings < $max_servings) {
            $max_servings = $possible_servings;
        }
    }

    $menu_html .= '<div class="col-sm-6 col-md-4 col-lg-3 mb-4">';
    $menu_html .= '<div class="card h-100">';
    $menu_html .= '<img class="card-img-top" src="' . (!empty($row['image']) && file_exists('../' . $row['image']) ? htmlspecialchars($row['image']) : 'placeholder.jpg') . '" alt="' . htmlspecialchars($row['name']) . '">';
    $menu_html .= '<div class="card-body d-flex flex-column">';
    $menu_html .= '<h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>';
    $menu_html .= '<p class="card-text">' . htmlspecialchars($row['description']) . '</p>';
    $menu_html .= '<p class="price mb-2"><i class="fa-solid fa-peso-sign me-1"></i>' . number_format($row['price'], 2) . '</p>';

    if ($can_make && $max_servings > 0) {
        $menu_html .= '<form onsubmit="return addToCart(event, ' . $row['id'] . ', this.quantity.value)" class="mt-auto">';
        $menu_html .= '<label>Qty:</label>';
        $menu_html .= '<input type="number" name="quantity" value="1" min="1" max="' . $max_servings . '" required class="form-control mb-2">';
        $menu_html .= '<button type="submit" class="btn btn-success w-100"><i class="fa-solid fa-cart-plus me-2"></i>Add to Cart</button>';
        $menu_html .= '</form>';
    } else {
        $menu_html .= '<div class="out-of-stock text-danger mt-auto">Out of Stock</div>';
    }
    $menu_html .= '</div></div></div>';
}

echo $menu_html;
exit;