<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$finishedCount = 0;
$totalSales = 0;

$completedOrderResult = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status = 'completed'");
$finishedCount = ($completedOrderResult && $row = $completedOrderResult->fetch_assoc()) ? $row['total'] : 0;

$totalSalesResult = $conn->query("SELECT SUM(total_price) AS total FROM sales");
$totalSales = ($totalSalesResult && $row = $totalSalesResult->fetch_assoc()) ? $row['total'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard - The Burgis</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: beige;
      margin: 0;
    }

    .sidebar {
      width: 240px;
      height: 100vh;
      background-color: #2f6907;
      padding: 20px 15px;
      position: fixed;
      top: 0;
      left: 0;
      color: white;
    }

    .sidebar h4 {
      text-align: center;
      font-weight: bold;
      margin-bottom: 30px;
    }

    .sidebar .nav-link {
      color: white;
      font-size: 16px;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      padding: 10px;
      border-radius: 8px;
      transition: background 0.3s;
    }

    .sidebar .nav-link:hover {
      background-color: #4a9e11;
      text-decoration: none;
    }

    .sidebar .nav-link i {
      margin-right: 10px;
      font-size: 18px;
    }

    .content {
      margin-left: 260px;
      padding: 40px 30px;
    }

    .content h2 {
      color: #2f6907;
      font-weight: bold;
      display: flex;
      align-items: center;
    }

    .content h2 i {
      margin-right: 10px;
    }

    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }

    .card-box {
      background: white;
      border-left: 8px solid #2f6907;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
      padding: 25px 20px;
      text-align: center;
      transition: transform 0.2s ease;
    }

    .card-box:hover {
      transform: translateY(-4px);
    }

    .card-box i {
      font-size: 36px;
      color: #2f6907;
    }

    .card-title {
      font-weight: bold;
      font-size: 18px;
      margin-top: 15px;
    }

    .card-value {
      font-size: 26px;
      margin-top: 8px;
      color: #333;
    }

    .alert {
      margin-top: 15px;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: relative;
        width: 100%;
        height: auto;
      }

      .content {
        margin-left: 0;
        padding: 20px;
      }
    }
    .sidebar .nav-link i {
    margin-right: 10px;
    transition: transform 0.2s ease;
}

.sidebar .nav-link:hover i {
    transform: scale(1.2);
}

  </style>
</head>

<body>

 <div class="sidebar">
    <h4><i class="fas fa-user-shield me-2"></i>Admin Panel</h4>
    <a href="inventory.php" class="nav-link"><i class="fas fa-warehouse me-2"></i>Inventory</a>
    <a href="add_item.php" class="nav-link"><i class="fas fa-plus-circle me-2"></i>Add Menu Item</a>
    <a href="sales_report.php" class="nav-link"><i class="fas fa-chart-line me-2"></i>Sales Report</a>
    <a href="../logout.php" class="nav-link"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a>
    
</div>

  <!-- Main Content -->
  <div class="content">
    <h2><i class="fas fa-home"></i> Welcome, Admin!</h2>

    <?php if (isset($_GET['reset']) && $_GET['reset'] === 'success'): ?>
      <div class="alert alert-success">✅ All best sellers have been reset.</div>
    <?php endif; ?>

    <p>Select an action from the sidebar to manage QuickBite Express.</p>

    <div class="dashboard-cards">
      <div class="card-box">
        <i class="fas fa-check-circle"></i>
        <div class="card-title">Completed Orders</div>
        <div class="card-value"><?= $finishedCount ?></div>
      </div>
      <div class="card-box">
        <i class="fas fa-coins"></i>
        <div class="card-title">Total Sales</div>
        <div class="card-value">₱<?= number_format($totalSales, 2) ?></div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
