<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM menu_items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$item = $result->fetch_assoc();

$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image = $item['image'];

    // Update image if new one is uploaded
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "../uploads/";
        $filename = uniqid() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image = "uploads/" . $filename;
        }
    }

    // Get previous stock value
    $prev_stock = $item['stock'];
    $stock_diff = $stock - $prev_stock;

    $can_update = true;

    // Only check if increasing stock
    if ($stock_diff > 0) {
        $ing_stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
        $ing_stmt->bind_param("i", $id);
        $ing_stmt->execute();
        $ingredients = $ing_stmt->get_result();

        while ($row = $ingredients->fetch_assoc()) {
            $ingredient_id = $row['ingredient_id'];
            $quantity_needed = $row['quantity_needed'];
            $update_amount = $stock_diff * $quantity_needed;

            // Get current ingredient stock
            $stock_stmt = $conn->prepare("SELECT name, stock FROM ingredients WHERE id = ?");
            $stock_stmt->bind_param("i", $ingredient_id);
            $stock_stmt->execute();
            $stock_result = $stock_stmt->get_result();
            $ingredient = $stock_result->fetch_assoc();
            $ingredient_name = $ingredient['name'];
            $ingredient_stock = $ingredient['stock'];
            $stock_stmt->close();

            if ($ingredient_stock < $update_amount) {
                $can_update = false;
                $error_msg .= "Not enough stock for ingredient <b>$ingredient_name</b> (needed: $update_amount, available: $ingredient_stock).<br>";
            }
        }
        $ing_stmt->close();
    }

    if ($can_update) {
        $stmt = $conn->prepare("UPDATE menu_items SET name=?, description=?, price=?, stock=?, image=? WHERE id=?");
        $stmt->bind_param("ssdisi", $name, $desc, $price, $stock, $image, $id);
        $stmt->execute();

        // Automatically update ingredient stocks
        if ($stock_diff != 0) {
            $ing_stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
            $ing_stmt->bind_param("i", $id);
            $ing_stmt->execute();
            $ingredients = $ing_stmt->get_result();

            while ($row = $ingredients->fetch_assoc()) {
                $ingredient_id = $row['ingredient_id'];
                $quantity_needed = $row['quantity_needed'];
                $update_amount = $stock_diff * $quantity_needed;
                $update_stmt = $conn->prepare("UPDATE ingredients SET stock = stock - ? WHERE id = ?");
                $update_stmt->bind_param("ii", $update_amount, $ingredient_id);
                $update_stmt->execute();
                $update_stmt->close();
            }
            $ing_stmt->close();
        }

        header("Location: inventory.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Menu Item</title>
</head>

<body>
    <h2>✏️ Edit Menu Item</h2>
    <a href="inventory.php">← Back to Inventory</a><br><br>

    <?php if (!empty($error_msg)): ?>
        <div style="color:red;font-weight:bold;"><?= $error_msg ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label>Name:</label><br>
        <input type="text" name="name" value="<?= htmlspecialchars($item['name']) ?>" required><br><br>

        <label>Description:</label><br>
        <textarea name="description" required><?= htmlspecialchars($item['description']) ?></textarea><br><br>

        <label>Price (₱):</label><br>
        <input type="number" name="price" step="0.01" value="<?= $item['price'] ?>" required><br><br>

        <label>Stock:</label><br>
        <input type="number" name="stock" value="<?= $item['stock'] ?>" required><br><br>

        <label>Replace Image:</label><br>
        <input type="file" name="image" accept="image/*"><br><br>

        <button type="submit">Update Item</button>
    </form>
</body>

</html>