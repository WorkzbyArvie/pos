<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id > 0) {
    // Delete links in menu_item_ingredients first
    $link_stmt = $conn->prepare("DELETE FROM menu_item_ingredients WHERE ingredient_id = ?");
    if ($link_stmt) {
        $link_stmt->bind_param("i", $id);
        $link_stmt->execute();
        $link_stmt->close();
    } else {
        die("Prepare failed for menu_item_ingredients: " . $conn->error);
    }

    $stmt = $conn->prepare("DELETE FROM ingredients WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    } else {
        die("Prepare failed for ingredients: " . $conn->error);
    }
}

header("Location: inventory.php");
exit;