<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg = "";
$ingredients_list = $conn->query("SELECT id, name FROM ingredients");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $image_path = null;

    $has_ingredient = false;
    if (isset($_POST['ingredient_id']) && isset($_POST['quantity_needed'])) {
        foreach ($_POST['quantity_needed'] as $qty) {
            if (intval($qty) > 0) {
                $has_ingredient = true;
                break;
            }
        }
    }

    if (!$has_ingredient) {
        $msg = "❌ Please link at least one ingredient.";
    } else {
        $check_stmt = $conn->prepare("SELECT id FROM menu_items WHERE name = ?");
        $check_stmt->bind_param("s", $name);
        $check_stmt->execute();
        $check_stmt->store_result();
        if ($check_stmt->num_rows > 0) {
            $msg = "❌ Menu item name already exists.";
        } else {
            if (!empty($_FILES['image']['name'])) {
                $target_dir = "../uploads/";
                $filename = uniqid() . "_" . basename($_FILES['image']['name']);
                $target_file = $target_dir . $filename;
                $image_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                if (in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                        $image_path = "uploads/" . $filename;
                    } else {
                        $msg = "❌ Failed to upload image.";
                    }
                } else {
                    $msg = "❌ Invalid image file type.";
                }
            }

            $stmt = $conn->prepare("INSERT INTO menu_items (name, description, price, image) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssds", $name, $desc, $price, $image_path);
            if ($stmt->execute()) {
                $new_item_id = $stmt->insert_id;
                foreach ($_POST['ingredient_id'] as $idx => $ingredient_id) {
                    $quantity_needed = intval($_POST['quantity_needed'][$idx]);
                    if ($ingredient_id && $quantity_needed > 0) {
                        $link_stmt = $conn->prepare("INSERT INTO menu_item_ingredients (menu_item_id, ingredient_id, quantity_needed) VALUES (?, ?, ?)");
                        $link_stmt->bind_param("iii", $new_item_id, $ingredient_id, $quantity_needed);
                        $link_stmt->execute();
                    }
                }
                $msg = "✅ Item and ingredients added successfully!";
            } else {
                $msg = "❌ Error adding item.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Add Menu Item - QuickBite Express</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color:beige;
      font-family: 'Segoe UI', sans-serif;
    }
    .container {
      max-width: 650px;
      margin-top: 50px;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
      animation: fadeInUp 0.8s ease;
    }
    h3 {
      color: #2f6907;
      font-weight: bold;
    }
    label, .form-label {
      font-weight: 500;
      color: #2f6907;
    }
    .form-control {
      border-radius: 8px;
    }
    .btn-primary {
      background-color: #2f6907;
      border: none;
    }
    .btn-primary:hover {
      background-color: #235004;
    }
    .btn-back {
      color: #2f6907;
      text-decoration: none;
      font-weight: 500;
    }
    .btn-back:hover {
      text-decoration: underline;
    }
    .icon {
      margin-right: 8px;
      color: #2f6907;
    }
    .alert-info {
      background-color: #eafbe2;
      color: #2f6907;
      border: 1px solid #cdecc3;
    }
    @keyframes fadeInUp {
      from {opacity: 0; transform: translateY(30px);}
      to {opacity: 1; transform: translateY(0);}
    }
  </style>
</head>

<body>
  <div class="container">
    <a href="dashboard.php" class="btn-back mb-3"><i class="bi bi-arrow-left-circle"></i> Back to Dashboard</a>
    <h3><i class="bi bi-plus-circle icon"></i>Add New Menu Item</h3>

    <?php if (!empty($msg)): ?>
      <div class="alert alert-info mt-3"><?= $msg ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="mt-3">
      <div class="mb-3">
        <label class="form-label"><i class="bi bi-card-text icon"></i>Item Name:</label>
        <input type="text" class="form-control" name="name" required>
      </div>
      <div class="mb-3">
        <label class="form-label"><i class="bi bi-chat-left-dots icon"></i>Description:</label>
        <textarea class="form-control" name="description" rows="2" required></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label"><i class="bi bi-cash-coin icon"></i>Price (₱):</label>
        <input type="number" class="form-control" name="price" step="0.01" required>
      </div>
      <div class="mb-3">
        <label class="form-label"><i class="bi bi-image icon"></i>Image:</label>
        <input type="file" class="form-control" name="image" accept="image/*">
      </div>

      <h5 class="mt-4"><i class="bi bi-basket icon"></i>Ingredients</h5>
      <table class="table table-bordered mt-2">
        <thead class="table-light">
          <tr>
            <th>Ingredient</th>
            <th>Quantity Needed</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($ing = $ingredients_list->fetch_assoc()): ?>
            <tr>
              <td>
                <input type="hidden" name="ingredient_id[]" value="<?= $ing['id'] ?>">
                <?= htmlspecialchars($ing['name']) ?>
              </td>
              <td>
                <input type="number" class="form-control" name="quantity_needed[]" min="0" value="0">
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>

      <button type="submit" class="btn btn-primary w-100 mt-3">
        <i class="bi bi-check-circle-fill me-1"></i> Add Item
      </button>
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
