<?php
session_start();
include '../includes/db.php';

// Admin check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$error_msg = '';
if (isset($_SESSION['error_msg'])) {
    $error_msg = $_SESSION['error_msg'];
    unset($_SESSION['error_msg']);
}
if (isset($_SESSION['post_data'])) {
    $_POST = $_SESSION['post_data'];
    unset($_SESSION['post_data']);
}


if (isset($_GET['id']) && isset($_GET['toggle'])) {
    $id = intval($_GET['id']);
    $status = ($_GET['toggle'] === 'enable') ? 1 : 0;
    $stmt = $conn->prepare("UPDATE menu_items SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $status, $id);
    $stmt->execute();
    header("Location: inventory.php");
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['food_id'])) {
    $id = intval($_POST['food_id']);
    $name = trim($_POST['food_name']);
    $desc = trim($_POST['food_description']);
    $price = floatval($_POST['food_price']);
    $image_path = null;

    // Handle image upload
    if (!empty($_FILES['food_image']['name'])) {
        $target_dir = "../uploads/";
        $filename = uniqid() . "_" . basename($_FILES['food_image']['name']);
        $target_file = $target_dir . $filename;
        $image_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (in_array($image_type, ['jpg', 'jpeg', 'png', 'gif'])) {
            if (move_uploaded_file($_FILES['food_image']['tmp_name'], $target_file)) {
                $image_path = "uploads/" . $filename;
            }
        }
    }

    // Check for duplicate name (excluding current item)
    $check = $conn->prepare("SELECT id FROM menu_items WHERE name = ? AND id != ?");
    $check->bind_param("si", $name, $id);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        $_SESSION['error_msg'] = "A food item with this name already exists.";
        $_SESSION['post_data'] = $_POST;
        header("Location: inventory.php");
        exit;
    } else {
        // Update food item details
        if ($image_path) {
            $stmt = $conn->prepare("UPDATE menu_items SET name=?, description=?, price=?, image=? WHERE id=?");
            $stmt->bind_param("ssisi", $name, $desc, $price, $image_path, $id);
        } else {
            $stmt = $conn->prepare("UPDATE menu_items SET name=?, description=?, price=? WHERE id=?");
            $stmt->bind_param("ssdi", $name, $desc, $price, $id);
        }
        $stmt->execute();

        // Update ingredients
        if (isset($_POST['ingredient_id'], $_POST['quantity_needed'])) {
            $conn->query("DELETE FROM menu_item_ingredients WHERE menu_item_id = $id");
            foreach ($_POST['ingredient_id'] as $idx => $ing_id) {
                $qty = intval($_POST['quantity_needed'][$idx]);
                if ($qty > 0) {
                    $stmt = $conn->prepare("INSERT INTO menu_item_ingredients (menu_item_id, ingredient_id, quantity_needed) VALUES (?, ?, ?)");
                    $stmt->bind_param("iii", $id, $ing_id, $qty);
                    $stmt->execute();
                }
            }
        }
    }
}

// Handle Ingredient Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ingredient_id'], $_POST['ingredient_name'], $_POST['ingredient_stock'])) {
    $id = intval($_POST['ingredient_id']);
    $name = trim($_POST['ingredient_name']);
    $stock = intval($_POST['ingredient_stock']);
    $stmt = $conn->prepare("UPDATE ingredients SET name=?, stock=? WHERE id=?");
    $stmt->bind_param("sii", $name, $stock, $id);
    $stmt->execute();
}

// Handle Add Ingredient
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_ingredient_name'])) {
    $name = trim($_POST['new_ingredient_name']);
    $stock = intval($_POST['new_ingredient_stock']);
    $stmt = $conn->prepare("INSERT INTO ingredients (name, stock) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $stock);
    $stmt->execute();
}

$result = $conn->query("SELECT * FROM menu_items");
$ingredients = $conn->query("SELECT * FROM ingredients");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Inventory - QuickBite Express</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-nx2rh3cV4vZk5ZwEDoszNkkgaUcZ6OaLHTu50Q2Z3qv8qAv9ZGF4z+Ma10kO/CH6qF/fJMS6shyPkYq1dvOw8g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            background-color:beige;
            font-family: 'Segoe UI', sans-serif;
            animation: fadeIn 0.8s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h3 {
            color: #2f6907;
            font-weight: bold;
            margin-bottom: 20px;
            animation: slideInLeft 0.6s ease;
        }

        @keyframes slideInLeft {
            from { transform: translateX(-30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .btn-back {
            background-color: #2f6907;
            color: white;
            border: none;
            animation: slideInRight 0.6s ease;
        }

        @keyframes slideInRight {
            from { transform: translateX(30px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .btn-back:hover {
            background-color: #265604;
        }

        .btn-primary,
        .btn-danger {
            background-color: #2f6907 !important;
            border: none;
        }

        .btn-primary:hover,
        .btn-danger:hover {
            background-color: #265604 !important;
        }

        .table-container {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 40px;
            animation: fadeIn 1s ease;
        }

        thead {
            background-color: #2f6907;
            color: white;
        }

        .table img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            display: block;
        }

        .table td {
            vertical-align: middle;
        }

        .notification {
            background-color: #ffc700;
            color: #2f2f2f;
            border-radius: 8px;
            padding: 10px 15px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .low-stock {
            color: red;
            font-weight: bold;
        }

        .ok-stock {
            color: green;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Food Inventory</h3>
            <a href="dashboard.php" class="btn btn-back">Return to Admin Page</a>
        </div>

        <!-- Food Inventory Table -->
        <div class="table-container">
            <table class="table table-bordered table-hover align-middle text-center">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Price (₱)</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <?php if (!empty($row['image'])): ?>
                                    <img src="../<?= htmlspecialchars($row['image']) ?>" alt="Image">
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td>₱<?= number_format($row['price'], 2) ?></td>
                            <td>
                                <?php if ($row['is_active']): ?>
                                    <span class="ok-stock">Enabled</span>
                                <?php else: ?>
                                    <span class="low-stock">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-sm btn-primary" href="#" data-bs-toggle="modal"
                                    data-bs-target="#editFoodModal" data-id="<?= $row['id'] ?>"
                                    data-name="<?= htmlspecialchars($row['name']) ?>"
                                    data-description="<?= htmlspecialchars($row['description']) ?>"
                                    data-price="<?= $row['price'] ?>">Edit</a>
                                <?php if ($row['is_active']): ?>
                                    <a class="btn btn-sm btn-warning" href="inventory.php?id=<?= $row['id'] ?>&toggle=disable"
                                        onclick="return confirm('Disable this item?');">Disable</a>
                                <?php else: ?>
                                    <a class="btn btn-sm btn-success" href="inventory.php?id=<?= $row['id'] ?>&toggle=enable"
                                        onclick="return confirm('Enable this item?');">Enable</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Ingredients Inventory Table -->
        <h3>Ingredients Inventory</h3>
        <div class="text-end mb-3">
            <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#addIngredientModal">➕ Add
                Ingredient</a>
        </div>
        <div class="table-container">
            <table class="table table-bordered table-hover align-middle text-center">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($ing = $ingredients->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($ing['name']) ?></td>
                            <td><?= max(0, (int) $ing['stock']) ?></td>
                            <td>
                                <?php if ($ing['stock'] < 5): ?>
                                    <span class="low-stock">Low Stock!</span>
                                <?php else: ?>
                                    <span class="ok-stock">OK</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-sm btn-primary" href="#" data-bs-toggle="modal"
                                    data-bs-target="#editIngredientModal" data-id="<?= $ing['id'] ?>"
                                    data-name="<?= htmlspecialchars($ing['name']) ?>"
                                    data-stock="<?= $ing['stock'] ?>">Edit</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Food Edit Modal -->
    <div class="modal fade" id="editFoodModal" tabindex="-1" aria-labelledby="editFoodModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" id="foodEditForm" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="editFoodModalLabel">Edit Food Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if (!empty($error_msg)): ?>
                        <div class="alert alert-danger"><?= $error_msg ?></div>
                    <?php endif; ?>
                    <input type="hidden" name="food_id" id="food_id"
                        value="<?= htmlspecialchars($_POST['food_id'] ?? '') ?>">
                    <div class="mb-3">
                        <label class="form-label">Name:</label>
                        <input type="text" class="form-control" name="food_name" id="food_name" required
                            value="<?= htmlspecialchars($_POST['food_name'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description:</label>
                        <textarea class="form-control" name="food_description" id="food_description" rows="2"
                            required><?= htmlspecialchars($_POST['food_description'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Price (₱):</label>
                        <input type="number" class="form-control" name="food_price" id="food_price" step="0.01" required
                            value="<?= htmlspecialchars($_POST['food_price'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Image:</label>
                        <input type="file" class="form-control" name="food_image" id="food_image" accept="image/*">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Ingredients Needed:</label>
                        <div id="ingredients-list">
                            <?php
                            // If there is an error and POST data, render the ingredients fields with POST values
                            if (!empty($error_msg) && isset($_POST['ingredient_id'], $_POST['quantity_needed'])) {
                                include 'get_food_ingredients.php';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Ingredient Edit Modal -->
    <div class="modal fade" id="editIngredientModal" tabindex="-1" aria-labelledby="editIngredientModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" id="ingredientEditForm" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="editIngredientModalLabel">Edit Ingredient</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="ingredient_id" id="ingredient_id">
                    <div class="mb-3">
                        <label class="form-label">Name:</label>
                        <input type="text" class="form-control" name="ingredient_name" id="ingredient_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Stock:</label>
                        <input type="number" class="form-control" name="ingredient_stock" id="ingredient_stock"
                            required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Ingredient Modal -->
    <div class="modal fade" id="addIngredientModal" tabindex="-1" aria-labelledby="addIngredientModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <form class="modal-content" id="addIngredientForm" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="addIngredientModalLabel">Add Ingredient</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Name:</label>
                        <input type="text" class="form-control" name="new_ingredient_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Stock:</label>
                        <input type="number" class="form-control" name="new_ingredient_stock" min="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Add Ingredient</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Food modal
            var foodModal = document.getElementById('editFoodModal');
            foodModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                document.getElementById('food_id').value = button.getAttribute('data-id');
                document.getElementById('food_name').value = button.getAttribute('data-name');
                document.getElementById('food_description').value = button.getAttribute('data-description');
                document.getElementById('food_price').value = button.getAttribute('data-price');
                // Load ingredients for this food item (AJAX only if not error)
                <?php if (empty($error_msg)): ?>
                    var foodId = button.getAttribute('data-id');
                    fetch('get_food_ingredients.php?id=' + foodId)
                        .then(res => res.text())
                        .then(html => {
                            document.getElementById('ingredients-list').innerHTML = html;
                        });
                <?php endif; ?>
            });

            // Ingredient modal
            var ingModal = document.getElementById('editIngredientModal');
            ingModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                document.getElementById('ingredient_id').value = button.getAttribute('data-id');
                document.getElementById('ingredient_name').value = button.getAttribute('data-name');
                document.getElementById('ingredient_stock').value = button.getAttribute('data-stock');
            });
        });
    </script>
    <?php if (!empty($error_msg)): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var foodModal = new bootstrap.Modal(document.getElementById('editFoodModal'));
                foodModal.show();
            });
        </script>
    <?php endif; ?>
</body>

</html>