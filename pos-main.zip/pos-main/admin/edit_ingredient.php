<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM ingredients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$ingredient = $result->fetch_assoc();

$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stock = intval($_POST['stock']);
    if ($stock < 0) {
        $error_msg = "Stock cannot be negative.";
    } else {
        $update = $conn->prepare("UPDATE ingredients SET stock = ? WHERE id = ?");
        $update->bind_param("ii", $stock, $id);
        $update->execute();
        header("Location: inventory.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Ingredient</title>
</head>

<body>
    <h2>✏️ Edit Ingredient Stock</h2>
    <a href="inventory.php">← Back to Inventory</a><br><br>

    <?php if (!empty($error_msg)): ?>
        <div style="color:red;font-weight:bold;"><?= $error_msg ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Name:</label><br>
        <input type="text" value="<?= htmlspecialchars($ingredient['name']) ?>" disabled><br><br>

        <label>Stock:</label><br>
        <input type="number" name="stock" value="<?= $ingredient['stock'] ?>" min="0" required><br><br>

        <button type="submit">Update Stock</button>
    </form>
</body>

</html>