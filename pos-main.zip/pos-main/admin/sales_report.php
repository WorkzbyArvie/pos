<?php
session_start();
include '../includes/db.php';

// Restrict access to admin only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Get filter inputs
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$product_id = $_GET['product_id'] ?? '';

// Build base query
$sql = "SELECT s.*, m.name AS item_name
        FROM sales s
        JOIN menu_items m ON s.menu_item_id = m.id
        WHERE 1";

if (!empty($start_date)) {
    $sql .= " AND s.sale_date >= '$start_date 00:00:00'";
}
if (!empty($end_date)) {
    $sql .= " AND s.sale_date <= '$end_date 23:59:59'";
}
if (!empty($product_id)) {
    $sql .= " AND s.menu_item_id = " . intval($product_id);
}

$sql .= " ORDER BY s.sale_date DESC";

$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}

// Get product list for dropdown
$products = $conn->query("SELECT id, name FROM menu_items");

$total_sales = 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Sales Report - QuickBite Express</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: beige;
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }

        h3 {
            color: #2f6907;
            font-weight: bold;
        }

        .btn-back {
            background-color: #2f6907;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-back:hover {
            background-color: #265703;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            padding: 20px;
            background: white;
            animation: fadeIn 0.4s ease-in-out;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .table-hover tbody tr:hover {
            background-color: #f0f8ec;
            transition: background-color 0.3s ease;
        }

        .btn-success {
            background-color: #2f6907 !important;
            border-color: #2f6907 !important;
        }

        .btn-success:hover {
            background-color: #265703 !important;
            border-color: #265703 !important;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3><i class="bi bi-graph-up-arrow me-2"></i>Sales Report</h3>
            <a href="dashboard.php" class="btn btn-back"><i class="bi bi-arrow-left-circle me-1"></i>Back to Dashboard</a>
        </div>

        <div class="card mb-4">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">📅 Start Date</label>
                    <input type="date" id="start_date" name="start_date" class="form-control"
                        value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">📅 End Date</label>
                    <input type="date" id="end_date" name="end_date" class="form-control"
                        value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="product_id" class="form-label">🍔 Product</label>
                    <select id="product_id" name="product_id" class="form-select">
                        <option value="">-- All --</option>
                        <?php while ($p = $products->fetch_assoc()): ?>
                            <option value="<?= $p['id'] ?>" <?= ($product_id == $p['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($p['name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button class="btn btn-success w-100" type="submit"><i class="bi bi-funnel me-1"></i>Filter</button>
                </div>
            </form>
        </div>

        <div class="card">
            <?php if ($result->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center">
                        <thead class="table-light">
                            <tr>
                                <th><i class="bi bi-calendar2-week"></i> Date & Time</th>
                                <th><i class="bi bi-box-seam"></i> Item</th>
                                <th><i class="bi bi-123"></i> Quantity</th>
                                <th><i class="bi bi-cash-coin"></i> Total Price (₱)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()):
                                $total_sales += $row['total_price'];
                                ?>
                                <tr>
                                    <td><?= date("Y-m-d H:i:s", strtotime($row['sale_date'])) ?></td>
                                    <td><?= htmlspecialchars($row['item_name']) ?></td>
                                    <td><?= $row['quantity'] ?></td>
                                    <td>₱<?= number_format($row['total_price'], 2) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-success">
                                <td colspan="3" class="text-end"><strong>Total Sales:</strong></td>
                                <td><strong>₱<?= number_format($total_sales, 2) ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center mb-0">
                    <i class="bi bi-exclamation-circle-fill me-2"></i>No sales data found for the selected filters.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
