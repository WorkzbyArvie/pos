<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $stock = intval($_POST['stock']);

    if ($name === '' || $stock < 0) {
        $error = "Please enter a valid name and stock quantity.";
    } else {
        $stmt = $conn->prepare("INSERT INTO ingredients (name, stock) VALUES (?, ?)");
        $stmt->bind_param("si", $name, $stock);
        $stmt->execute();
        header("Location: inventory.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Add Ingredient</title>
    <style>
        body {
            font-family: Arial;
            padding: 30px;
        }

        form {
            max-width: 400px;
            margin: auto;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 8px 16px;
            background: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <h2>➕ Add Ingredient</h2>
    <a href="inventory.php">← Back to Inventory</a>
    <br><br>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <label for="name">Ingredient Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="stock">Initial Stock:</label>
        <input type="number" name="stock" id="stock" min="0" required>

        <button type="submit">Add Ingredient</button>
    </form>
</body>

</html>