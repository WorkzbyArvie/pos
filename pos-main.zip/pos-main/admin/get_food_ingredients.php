<?php
include '../includes/db.php';

$food_id = intval($_GET['id'] ?? 0);

// Get all ingredients
$all_ingredients = [];
$res = $conn->query("SELECT id, name FROM ingredients");
while ($row = $res->fetch_assoc()) {
    $all_ingredients[$row['id']] = $row['name'];
}

// Get current ingredients for this food item
$current = [];
$stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
$stmt->bind_param("i", $food_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $current[$row['ingredient_id']] = $row['quantity_needed'];
}

// Output form fields
foreach ($all_ingredients as $id => $name) {
    // Use POST value if available (after error), else DB value
    $qty = '';
    if (isset($_POST['ingredient_id'], $_POST['quantity_needed'])) {
        foreach ($_POST['ingredient_id'] as $idx => $ing_id) {
            if ($ing_id == $id) {
                $qty = $_POST['quantity_needed'][$idx];
                break;
            }
        }
    } elseif (isset($current[$id])) {
        $qty = $current[$id];
    }
    echo '<div class="input-group mb-2">';
    echo '<span class="input-group-text">' . htmlspecialchars($name) . '</span>';
    echo '<input type="hidden" name="ingredient_id[]" value="' . $id . '">';
    echo '<input type="number" min="0" step="1" class="form-control" name="quantity_needed[]" value="' . htmlspecialchars($qty) . '" placeholder="0">';
    echo '</div>';
}
?>