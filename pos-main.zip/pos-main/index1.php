<?php
session_start();
include 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? 1;

// Fetch menu items
$sql = "SELECT * FROM menu_items WHERE status = 'active' AND is_active = 1 ORDER BY sales_count DESC";
$menuItems = $conn->query($sql);

// Fetch cart items
$cart_stmt = $conn->prepare("SELECT c.id AS cart_id, m.name, m.price, c.quantity, (m.price * c.quantity) AS total 
                             FROM cart c JOIN menu_items m ON c.menu_item_id = m.id 
                             WHERE c.user_id = ?");
$cart_stmt->bind_param("i", $user_id);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

$cart_items = [];
$grand_total = 0;
while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $grand_total += $row['total'];
}
// Fetch Preparing orders
$prep_sql = "SELECT o.id, o.sale_date, o.status, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
             FROM orders o
             JOIN order_queue oq ON o.id = oq.order_id
             JOIN menu_items mi ON oq.menu_item_id = mi.id
             WHERE o.status IN ('Preparing')
             GROUP BY o.id
             ORDER BY o.sale_date DESC";
$prep_stmt = $conn->prepare($prep_sql);
$prep_stmt->execute();
$preparing_orders = $prep_stmt->get_result();

// Fetch Ready orders
$ready_sql = "SELECT o.id, o.sale_date, GROUP_CONCAT(CONCAT(mi.name, ' x', oq.quantity) SEPARATOR '<br>') AS items
              FROM orders o
              JOIN order_queue oq ON o.id = oq.order_id
              JOIN menu_items mi ON oq.menu_item_id = mi.id
              WHERE o.status = 'Ready'
              GROUP BY o.id
              ORDER BY o.sale_date DESC";
$ready_stmt = $conn->prepare($ready_sql);
$ready_stmt->execute();
$ready_orders = $ready_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>The Burgis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #fcf5ed;
        }

        .navbar {
            background-color: #2f6907;
            padding: 15px 30px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-right a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
        }

        .menu-title {
            text-align: center;
            margin: 30px 0 10px;
            color: #d73745;
            font-size: 28px;
            font-weight: bold;
        }

        .scroll-wrapper {
            position: relative;
            padding: 0 40px;
        }

        .scroll-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            background-color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            z-index: 2;
        }

        .scroll-btn.left {
            left: 0;
        }

        .scroll-btn.right {
            right: 0;
        }

        .menu-container {
            display: flex;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            gap: 20px;
            padding: 10px 20px 40px;
            scroll-behavior: smooth;
        }

        .menu-container::-webkit-scrollbar {
            height: 8px;
        }

        .menu-container::-webkit-scrollbar-thumb {
            background: #ccc;
            border-radius: 10px;
        }

        .card {
            animation: slideInUp 0.5s ease both;
            width: 100%;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 15px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.03);
        }

        .card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .price {
            font-weight: bold;
            margin: 8px 0;
            color: #333;
        }

        .out-of-stock {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }

        input[type="number"] {
            width: 60px;
            padding: 4px;
            margin-right: 5px;
        }

        button {
            padding: 6px 12px;
            background-color: #28a745;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        button:disabled {
            background-color: gray;
            cursor: not-allowed;
        }

        .toast-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1055;
        }

        .modal-body {
            padding: 25px;
        }

        .modal-footer {
            padding: 20px 25px;
        }
        .reservation-body {
        background: linear-gradient(145deg, #e0f8d8, #f0fff0);
        padding: 30px;
        border-radius: 0 0 15px 15px;
    }

    .reservation-body .form-control,
    .reservation-body .form-select {
        transition: 0.3s;
    }

    .reservation-body .form-control:focus,
    .reservation-body .form-select:focus {
        border-color: #2f6907;
        box-shadow: 0 0 10px rgba(47, 105, 7, 0.3);
    }

    .modal-header.bg-success {
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }

    .btn-lg {
        font-weight: 600;
        font-size: 1.1rem;
    }

    /* Optional hover effect on inputs */
    .reservation-body .form-control:hover,
    .reservation-body .form-select:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(47, 105, 7, 0.25);
    }

        @keyframes slideInUp {
            0% {
                opacity: 0;
                transform: translateY(30px);
            }

            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.06);
            }

            100% {
                transform: scale(1);
            }
        }

        @keyframes popIn {
            0% {
                opacity: 0;
                transform: scale(0.85);
            }

            100% {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Apply animation to menu cards */
        .card {
            animation: slideInUp 0.5s ease both;
        }

        /* Toast fade-in */
        .toast {
            animation: fadeIn 0.6s ease;
        }

        /* Pulse effect on View Cart */
        .navbar-right a[data-bs-target="#cartModal"] {
            animation: pulse 1.6s ease-in-out infinite;
        }

        /* Modal pop-in effect */
        .modal-content {
            animation: popIn 0.4s ease;
        }
        

@keyframes bounceIn {
    0% { transform: translateY(-50px) scale(0.8); opacity: 0; }
    60% { transform: translateY(10px) scale(1.05); opacity: 1; }
    100% { transform: translateY(0) scale(1); }
}
    </style>
</head>

<body>

  <div class="navbar">
    <div class="navbar-left" style="cursor:pointer;" onclick="window.location.href='login.php';">
        <i class="fa-solid fa-burger me-2"></i> THE BURGIS
    </div>
    <div class="navbar-right">
        <a href="#" data-bs-toggle="modal" data-bs-target="#reservationModal">
            <i class="fa-solid fa-chair me-1"></i> Reserve Table
        </a>
        
        <a href="#" data-bs-toggle="modal" data-bs-target="#cartModal">
            <i class="fa-solid fa-cart-shopping me-1"></i> View Cart
        </a>
    </div>
</div>

    <div class="menu-title"><i class="fa-solid fa-utensils me-2"></i>Menu</div>




    <div class="container">
        <div class="row" id="menuScroll">
            <?php while ($row = $menuItems->fetch_assoc()): ?>
                <div class="col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="card h-100">
                        <img class="card-img-top"
                            src="<?= !empty($row['image']) && file_exists($row['image']) ? htmlspecialchars($row['image']) : 'placeholder.jpg' ?>"
                            alt="<?= htmlspecialchars($row['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($row['description']) ?></p>
                            <p class="price mb-2">₱<?= number_format($row['price'], 2) ?></p>
                            <?php
                            // Ingredient stock check (same as before)
                            $can_make = true;
                            $max_servings = PHP_INT_MAX;
                            $recipe_stmt = $conn->prepare("SELECT ingredient_id, quantity_needed FROM menu_item_ingredients WHERE menu_item_id = ?");
                            $recipe_stmt->bind_param("i", $row['id']);
                            $recipe_stmt->execute();
                            $recipe_result = $recipe_stmt->get_result();
                            if ($recipe_result->num_rows == 0) {
                                $can_make = false;
                            }
                            while ($ingredient = $recipe_result->fetch_assoc()) {
                                $ing_id = $ingredient['ingredient_id'];
                                $qty_needed = $ingredient['quantity_needed'];
                                if ($qty_needed <= 0)
                                    continue;
                                $ing_stock_result = $conn->query("SELECT stock FROM ingredients WHERE id = $ing_id");
                                $ing_stock = $ing_stock_result->fetch_assoc()['stock'] ?? 0;
                                if ($ing_stock < $qty_needed) {
                                    $can_make = false;
                                    break;
                                }
                                $possible_servings = intdiv($ing_stock, $qty_needed);
                                if ($possible_servings < $max_servings) {
                                    $max_servings = $possible_servings;
                                }
                            }
                            ?>
                            <?php if ($can_make && $max_servings > 0): ?>
                                <form onsubmit="return addToCart(event, <?= $row['id'] ?>, this.quantity.value)"
                                    class="mt-auto">
                                    <label>Qty:</label>
                                    <input type="number" name="quantity" value="1" min="1" max="<?= $max_servings ?>" required
                                        class="form-control mb-2">
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fa-solid fa-cart-plus me-2"></i>Add to Cart
                                    </button>
                                </form>
                            <?php else: ?>
                                <div class="out-of-stock text-danger mt-auto">Out of Stock</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>





    <!-- Toast -->
    <div class="toast-container">
        <div id="addedToast" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fa-solid fa-check-circle me-2"></i>Item added to cart!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Cart Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">

            <div class="modal-content">
                <form action="actions/checkout.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fa-solid fa-cart-shopping me-2"></i>Your Cart</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="cartModalBody">
                        <!-- Cart items will be loaded here via AJAX -->
                    </div>
                    <div class="modal-footer" id="cartModalFooter">
                        <!-- The checkout button will be loaded via AJAX as well -->
                    </div>
                </form>
            </div>
        </div>
    </div>
 
    <!-- ✅ Reservation Modal -->
<div class="modal fade" id="reservationModal" tabindex="-1" aria-labelledby="reservationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="reservationForm" method="POST" action="actions/make_reservation.php">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fa-solid fa-chair me-2"></i>Reserve a Table</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body reservation-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label"><i class="fa-solid fa-user me-1"></i>Name</label>
                            <input type="text" class="form-control rounded-pill shadow-sm" name="user_name" placeholder="Your Name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><i class="fa-solid fa-phone me-1"></i>Phone Number</label> 
                            <input type="tel" id="phone" class="form-control rounded-pill shadow-sm" name="phone" placeholder="0912-345-6789" pattern="[0-9]{4}[0-9]{3}[0-9]{4}" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><i class="fa-solid fa-chair me-1"></i>Table Category</label>
                            <select class="form-select rounded-pill shadow-sm" id="tableCategory" name="table_category" required>
                                <option value="">Select Category</option>
                                <option value="small"> 2-4Pax (1–5)</option>
                                <option value="medium">5-7Pax (6–10)</option>
                                <option value="large">8-12Pax (11–15)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><i class="fa-solid fa-table me-1"></i>Table Number</label>
                            <select class="form-select rounded-pill shadow-sm" id="tableNumber" name="table_number" required>
                                <option value="">Select Table</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label"><i class="fa-solid fa-calendar-days me-1"></i>Date & Time</label>
                            <input type="text" id="reservationDatetime" name="reservation_datetime" class="form-control rounded-pill shadow-sm" placeholder="Select Date & Time" required>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success btn-lg rounded-pill w-100 shadow-sm" type="submit">
                        <i class="fa-solid fa-check me-2"></i>Confirm Reservation
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>



        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
        flatpickr("#reservationDatetime", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    minDate: "today",
    time_24hr: false, // true for 24-hour format
    defaultHour: 12,
    defaultMinute: 0,
    minuteIncrement: 5
});
        function scrollMenu(direction) {
            const container = document.getElementById('menuScroll');
            const scrollAmount = 300;
            container.scrollLeft += direction === 'left' ? -scrollAmount : scrollAmount;
        }

        function loadCartModal() {
            fetch('actions/cart_modal_update1.php')
                .then(res => res.text())
                .then(html => {
                    // Split the returned HTML into body and footer if needed
                    // For simplicity, assume all content goes into modal body
                    document.getElementById('cartModalBody').innerHTML = html;

                    // If you want to move the checkout button to the footer, you can split it out in cart_modal.php
                    // Or, keep everything in the body for now
                });
        }

        // Load cart modal content every time the modal is shown
        document.addEventListener('DOMContentLoaded', function () {
            refreshMenu();

            // Show toast if needed
            if (localStorage.getItem('showToast') === '1') {
                setTimeout(() => {
                    const toast = new bootstrap.Toast(document.getElementById('addedToast'));
                    toast.show();
                    localStorage.removeItem('showToast');
                }, 300);
            }

            // Bootstrap 5 event for showing modal
            var cartModal = document.getElementById('cartModal');
            cartModal.addEventListener('show.bs.modal', function () {
                loadCartModal();
            });
        });

        function removeFromCart(cartId) {
            const cashInput = document.getElementById('cash');
            let currentCash = cashInput ? cashInput.value : '';

            fetch(`actions/remove_from_cart.php?id=${cartId}`)
                .then(res => res.json())
                .then(() => {
                    loadCartModal();
                    refreshMenu();
                })
                .catch(err => console.error("Error updating cart:", err));
        }

        function refreshMenu() {
            fetch('actions/menu_update.php')
                .then(res => res.text())
                .then(html => {
                    document.getElementById('menuScroll').innerHTML = html;
                });
        }

        function calculateChange() {
            const total = parseFloat(document.getElementById('grand_total')?.value) || 0;
            const cashInput = document.getElementById('cash');
            let cash = parseFloat(cashInput?.value);

            if (isNaN(cash) || cash < 0) cash = 0;

            let change = cash - total;
            const display = document.getElementById('change');
            display.innerText = 'Change: ₱' + Math.max(change, 0).toFixed(2);
        }
        // Handle order completion without page reload
        document.addEventListener('click', function (e) {
            if (e.target && e.target.classList.contains('complete-btn')) {
                e.preventDefault();

                const btn = e.target;
                const orderId = btn.dataset.orderId;

                if (!confirm("Mark this order as completed?")) return;

                fetch('complete_order.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'order_id=' + encodeURIComponent(orderId)
                })
                    .then(res => res.text())
                    .then(() => {
                        // Remove the row from the table or reload part of modal
                        const row = btn.closest('tr');
                        row.remove();
                    })
                    .catch(err => console.error("Failed to complete order:", err));
            }
        });
        function addToCart(event, itemId, quantity) {
            event.preventDefault();

            const formData = new FormData();
            formData.append('menu_item_id', itemId);
            formData.append('quantity', quantity);

            fetch('actions/add_to_cart.php', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const toast = new bootstrap.Toast(document.getElementById('addedToast'));
                        toast.show();
                        loadCartModal();
                        refreshMenu();
                    } else {
                        alert(data.error === 'ingredient_out_of_stock'
                            ? 'Not enough ingredients to fulfill your order.'
                            : 'Failed to add to cart.');
                    }
                })
                .catch(err => console.error("Add to cart failed:", err));

            return false;
        }
    document.getElementById('tableCategory').addEventListener('change', function() {
        const category = this.value;
        const tableSelect = document.getElementById('tableNumber');
        tableSelect.innerHTML = '<option value="">Loading...</option>';

        fetch('actions/get_tables.php?category=' + category)
            .then(res => res.json())
            .then(data => {
                tableSelect.innerHTML = '<option value="">Select Table</option>';
                data.forEach(num => {
                    let opt = document.createElement('option');
                    opt.value = num;
                    opt.textContent = "Table " + num;
                    tableSelect.appendChild(opt);
                });
            });
});

function updateTables() {
    const category = document.getElementById('tableCategory').value;
    const datetime = document.getElementById('reservationDatetime').value;
    const tableSelect = document.getElementById('tableNumber');
    tableSelect.innerHTML = '<option value="">Loading...</option>';

    if (!category || !datetime) {
        tableSelect.innerHTML = '<option value="">Select Category & Time first</option>';
        return;
    }

    fetch(`actions/get_tables.php?category=${category}&datetime=${datetime}`)
        .then(res => res.json())
        .then(data => {
            tableSelect.innerHTML = '';
            if (data.length === 0) {
                let opt = document.createElement('option');
                opt.textContent = "❌ No tables available for this time.";
                tableSelect.appendChild(opt);
                return;
            }
            data.forEach(num => {
                let opt = document.createElement('option');
                opt.value = num;
                opt.textContent = "Table " + num;
                tableSelect.appendChild(opt);
            });
        });
}


        document.getElementById('reservationForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = this;
    const formData = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Hide the modal
            const reservationModal = bootstrap.Modal.getInstance(document.getElementById('reservationModal'));
            reservationModal.hide();

            // Show success toast
            const toast = new bootstrap.Toast(document.getElementById('reservationToast'));
            toast.show();

            // Reset form
            form.reset();
            document.getElementById('tableNumber').innerHTML = '<option value="">Select Table</option>';
        } else {
            if (data.success) {
    Swal.fire({
        icon: 'success',
        title: 'Reservation Successful!',
        text: data.message,
        confirmButtonColor: '#2f6907',
        timer: 2500,
        timerProgressBar: true,
        showConfirmButton: false
    });
} else {
    Swal.fire({
        icon: 'error',
        title: 'Reservation Failed',
        text: data.message || 'Please try again.',
        confirmButtonColor: '#d73745'
    });
}

        }
    })
    .catch(err => console.error(err));
});
// Run availability check when user selects category or datetime
document.getElementById('tableCategory').addEventListener('change', updateTables);
document.getElementById('reservationDatetime').addEventListener('change', updateTables);

// Prevent past datetime selection
document.getElementById('reservationDatetime').min = new Date().toISOString().slice(0,16);
   
   
    </script>
    <!-- Receipt Modal -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-labelledby="receiptModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content" id="receiptModalContent">
                <!-- Dynamic content inserted via JS after checkout -->
            </div>
        </div>
    </div>
<!-- Reservation Success Toast -->
<div class="toast-container">
    <div id="reservationToast" class="toast align-items-center text-bg-success border-0" role="alert"
         aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <i class="fa-solid fa-check-circle me-2"></i>Reservation successful!
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
        </div>
    </div>
</div>

</body>

</html>