<?php
session_start();

// Unset all session variables
$_SESSION = [];

// If session uses cookies, clear the cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session completely
session_destroy();

// Redirect to login with message
header("Location: landing.php?loggedout=true");
exit;
?>
