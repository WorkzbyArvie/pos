<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'kitchen') {
    header("Location: login.php");
    exit;
}

$sqlQueued = "SELECT o.id, o.status, o.sale_date, GROUP_CONCAT(CONCAT(mi.name, ' x', oi.quantity) SEPARATOR '<br>') AS items
    FROM orders o
    JOIN order_queue oi ON o.id = oi.order_id
    JOIN menu_items mi ON oi.menu_item_id = mi.id
    WHERE o.status != 'Ready' AND o.status != 'Completed'
    GROUP BY o.id
    ORDER BY o.sale_date ASC";
$resultQueued = $conn->query($sqlQueued);

$sqlCompleted = "SELECT o.id, o.sale_date, GROUP_CONCAT(CONCAT(mi.name, ' x', oi.quantity) SEPARATOR '<br>') AS items
    FROM orders o
    JOIN order_queue oi ON o.id = oi.order_id
    JOIN menu_items mi ON oi.menu_item_id = mi.id
    WHERE o.status = 'Completed'
    GROUP BY o.id
    ORDER BY o.sale_date DESC";
$resultCompleted = $conn->query($sqlCompleted);
?>

<!DOCTYPE html>
<html>
<head>
    <title>The Burgis Kitchen Order Queue</title>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 40px;
            background: linear-gradient(to bottom, #f1fdf5, #e8ffe0);
            animation: fadeIn 0.6s ease-out;
        }

        h2 {
            color: #2f6907;
            margin-bottom: 20px;
            animation: fadeIn 0.8s ease-in-out;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-radius: 12px;
            overflow: hidden;
            animation: fadeIn 1s ease-in-out;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: center;
            font-size: 15px;
        }

        th {
            background-color: #cdeab8;
            color: #2f6907;
        }

        td {
            background-color: #ffffff;
        }

        select, button {
            padding: 6px 12px;
            border-radius: 6px;
            border: 1px solid #a2d186;
            font-size: 14px;
            background-color: #f5fff0;
            transition: all 0.3s ease-in-out;
        }

        select:focus, button:hover {
            background-color: #d9ffd0;
            cursor: pointer;
            transform: scale(1.03);
        }

        a {
            display: inline-block;
            margin-bottom: 25px;
            color: #2f6907;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        a:hover {
            text-decoration: underline;
            transform: translateX(-3px);
        }

        .section {
            background-color: white;
            border: 2px solid #2f6907;
            border-radius: 14px;
            padding: 30px;
            margin-bottom: 40px;
            animation: fadeIn 0.9s ease-in-out;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        button {
            background-color: #2f6907;
            color: white;
        }

        button:hover {
            background-color: #3e8e0a;
        }

        .btn-animate {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>

    <a href="login.php">← Back to Dashboard</a>

    <div class="section">
        <h2>👨‍🍳 Kitchen Order Queue</h2>

        <table>
            <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Items</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php if ($resultQueued && $resultQueued->num_rows > 0): ?>
                <?php while ($row = $resultQueued->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td><?= $row['sale_date'] ?></td>
                        <td><?= $row['items'] ?></td>
                        <td><?= $row['status'] ?></td>
                        <td>
                            <form method="POST" action="update_order_status.php">
                                <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                                <select name="status">
                                    <option value="Queued" <?= $row['status'] == 'Queued' ? 'selected' : '' ?>>Queued</option>
                                    <option value="Preparing" <?= $row['status'] == 'Preparing' ? 'selected' : '' ?>>Preparing</option>
                                    <option value="Ready" <?= $row['status'] == 'Ready' ? 'selected' : '' ?>>Ready</option>
                                </select>
                                <button type="submit" class="btn-animate">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5">No queued orders found.</td></tr>
            <?php endif; ?>
        </table>
    </div>

    <!-- Order status -->
    <div class="section">
        <h2>✅ Completed Orders</h2>

        <table>
            <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Items</th>
            </tr>
            <?php if ($resultCompleted && $resultCompleted->num_rows > 0): ?>
                <?php while ($row = $resultCompleted->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td><?= $row['sale_date'] ?></td>
                        <td><?= $row['items'] ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="3">No completed orders found.</td></tr>
            <?php endif; ?>
        </table>
    </div>

</body>
</html>
