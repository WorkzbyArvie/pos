<?php
session_start();
include 'includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $uname, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['role'] = $role;

            if ($role === 'admin') {
                header("Location: admin/dashboard.php");
            } elseif ($role === 'kitchen') {
                header("Location: kitchen_queue.php");
            } elseif ($role === 'customer') {
                header("Location: index1.php");
            }elseif ($role === 'cashier') {
                header("Location: index.php");
            }
            exit;
        } else {
            $error = "❌ Incorrect password.";
        }
    } else {
        $error = "❌ User not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - The Burgis</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html, body {
      height: 100%;
      font-family: 'Segoe UI', sans-serif;
      overflow: hidden;
    }

    .slideshow {
      position: fixed;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      z-index: -1;
    }

    .slideshow img {
      position: absolute;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0;
      animation: slideshow 20s infinite;
    }

    .slideshow img:nth-child(1) { animation-delay: 0s; }
    .slideshow img:nth-child(2) { animation-delay: 5s; }
    .slideshow img:nth-child(3) { animation-delay: 10s; }
    .slideshow img:nth-child(4) { animation-delay: 15s; }

    @keyframes slideshow {
      0% { opacity: 0; }
      5% { opacity: 1; }
      25% { opacity: 1; }
      30% { opacity: 0; }
      100% { opacity: 0; }
    }

    .login-container {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1;
      position: relative;
    }

    .login-box {
      background: rgba(255, 255, 255, 0.9);
      border-radius: 12px;
      padding: 40px 30px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      width: 100%;
      max-width: 400px;
    }

    .login-box h2 {
      color: #2f6907;
      font-weight: bold;
      margin-bottom: 25px;
      text-align: center;
    }

    .btn-custom {
      background-color: #2f6907;
      color: #ffffff;
      border: none;
    }

    .btn-custom:hover {
      background-color: #245605;
    }

    label {
      font-weight: 500;
      color: #2f6907;
    }

    .form-control:focus {
      border-color: #ffc700;
      box-shadow: 0 0 0 0.2rem rgba(255, 199, 0, 0.25);
    }

    .error-message {
      color: #dc3545;
      margin-top: 10px;
      font-size: 14px;
      text-align: center;
      
    }

     .btn-outline-secondary:hover {
    background-color: #2f6907 !important;
    color: white !important;
    border-color: #2f6907 !important;
  }
  </style>
</head>
<body>

  <!-- Background Slideshow -->
  <div class="slideshow">
    <img src="img/5.png" alt="Slide 1">
    <img src="img/6.png" alt="Slide 2">
    <img src="img/7.png" alt="Slide 3">
    <img src="img/8.png" alt="Slide 4">
  </div>

  <!-- Login Form -->
  <div class="login-container">
    
    <div class="login-box">
      <h2><i class="fas fa-user-shield me-2"></i>Login</h2>

      <?php if ($error): ?>
        <p class="error-message"><?= $error ?></p>
      <?php endif; ?>

      <form method="POST">
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" class="form-control" name="username" required>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <button type="submit" class="btn btn-custom w-100">Login</button>
      </form>
      
     
      <div class="d-flex justify-content-between align-items-center mt-2" style="font-size:14px;">
  <a href="forgot_password.php" style="color:#2f6907; text-decoration:none;">Forgot Password?</a>
 
  <a href="signup.php" style="color:#2f6907; text-decoration:none;">Sign Up</a>
</div>

<br>
      <div class="mt-3 d-flex justify-content-center">
        <a href="landing.php" class="btn btn-outline-secondary" style="width: 80%;">
          🔙 Back to Landing Page
        </a>
      </div>
    </div>
  </div>
<br>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
