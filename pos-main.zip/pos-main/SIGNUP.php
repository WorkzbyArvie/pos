<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "restaurant_system");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = isset($_POST["username"]) ? trim($_POST["username"]) : '';
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : '';
    $password = isset($_POST["password"]) ? $_POST["password"] : '';
    $confirm = isset($_POST["confirm_password"]) ? $_POST["confirm_password"] : '';

    // Basic validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = "Username or Email already registered.";
        } else {
            // Hash password
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            // Insert customer into users table
            $role = 'customer';
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $email, $hashed, $role);
            if ($stmt->execute()) {
                $success = "✅ Signup successful! You can now log in.";
            } else {
                $error = "❌ Signup failed. Please try again.";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Customer Signup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html,
        body {
            height: 100%;
            font-family: 'Segoe UI', sans-serif;
            overflow: hidden;
        }

        .slideshow {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            z-index: -1;
        }

        .slideshow img {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            animation: slideshow 20s infinite;
        }

        .slideshow img:nth-child(1) {
            animation-delay: 0s;
        }

        .slideshow img:nth-child(2) {
            animation-delay: 5s;
        }

        .slideshow img:nth-child(3) {
            animation-delay: 10s;
        }

        .slideshow img:nth-child(4) {
            animation-delay: 15s;
        }

        @keyframes slideshow {
            0% {
                opacity: 0;
            }

            5% {
                opacity: 1;
            }

            25% {
                opacity: 1;
            }

            30% {
                opacity: 0;
            }

            100% {
                opacity: 0;
            }
        }

        .login-container {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1;
            position: relative;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 12px;
            padding: 40px 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .login-box h2 {
            color: #2f6907;
            font-weight: bold;
            margin-bottom: 25px;
            text-align: center;
        }

        .btn-custom {
            background-color: #2f6907;
            color: #ffffff;
            border: none;
        }

        .btn-custom:hover {
            background-color: #245605;
        }

        label {
            font-weight: 500;
            color: #2f6907;
        }

        .form-control:focus {
            border-color: #ffc700;
            box-shadow: 0 0 0 0.2rem rgba(255, 199, 0, 0.25);
        }

        .error-message {
            color: #dc3545;
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }

        .success-message {
            color: #198754;
            margin-top: 10px;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>

<body>

    <!-- Background Slideshow -->
    <div class="slideshow">
        <img src="img/5.png" alt="Slide 1">
        <img src="img/6.png" alt="Slide 2">
        <img src="img/7.png" alt="Slide 3">
        <img src="img/8.png" alt="Slide 4">
    </div>

    <!-- Signup Form -->
    <div class="login-container">
        <div class="login-box">
            <h2><i class="fas fa-user-plus me-2"></i>Customer Signup</h2>

            <?php if ($error): ?>
                <p class="error-message"><?= $error ?></p>
            <?php endif; ?>
            <?php if ($success): ?>
                <p class="success-message"><?= $success ?></p>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-custom w-100">Sign Up</button>
            </form>

            <div class="mt-3 d-flex justify-content-center">
                <a href="login.php" class="btn btn-outline-secondary" style="width: 80%;">
                    🔙 Back to Login
                </a>
            </div>
        </div>
    </div>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>