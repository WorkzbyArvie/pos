-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2025 at 10:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `menu_item_id`, `quantity`) VALUES
(312, 22, 18, 1),
(313, 22, 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `stock`, `status`) VALUES
(3, 'Burger Bun', 93, 'active'),
(4, 'Beef Patty', 39, 'active'),
(5, 'Chicken Patty', 98, 'active'),
(6, 'Pickles', 46, 'active'),
(7, 'Cheese', 42, 'active'),
(8, 'Tomato', 26, 'active'),
(9, 'Ketchup', 42, 'active'),
(10, 'Onions', 63, 'active'),
(11, 'Lettuce', 26, 'active'),
(12, 'Egg', 100, 'active'),
(13, 'Mayonnaise', 1, 'active'),
(14, 'Coleslaw', 0, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('ingredient','menu_item') NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `alert_level` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sales_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `status` enum('active','disabled') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `name`, `description`, `price`, `image`, `sales_count`, `is_active`, `status`) VALUES
(7, 'Double Cheese Burger', 'Double Cheese and Patty Burger', 160.00, 'uploads/6878eb604b53a_double-patty.jpg', 1, 1, 'active'),
(8, 'Normal Burgers', 'Normal Burger with 1 patty', 50.00, 'uploads/6879449febe9a_images (2).jpg', 10, 1, 'active'),
(10, 'Triple Decker Burger', 'Triple the Price!', 299.00, 'uploads/688b2e2dd25c1_Tag a drinking buddy! - Served up at the @thehayberry was this dirty triple that was juicy AF!.jpg', 3, 1, 'active'),
(12, 'Flying dutch man', 'Special Burgir from in n out', 100.00, 'uploads/688b36620c64b_Delicious In-N-Out Style Flying Dutchman Burger Recipe.jpg', 1, 1, 'active'),
(18, 'Grilled Chicken Burger', 'Grilled chicken burger', 150.00, 'uploads/688c0e415d81f_Juicy-Grilled-Chicken-Burgers-Recipe-6-500x375.jpg', 1, 1, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `menu_item_ingredients`
--

CREATE TABLE `menu_item_ingredients` (
  `id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `quantity_needed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_item_ingredients`
--

INSERT INTO `menu_item_ingredients` (`id`, `menu_item_id`, `ingredient_id`, `quantity_needed`) VALUES
(15, 10, 3, 1),
(16, 10, 4, 3),
(17, 10, 7, 3),
(18, 10, 8, 2),
(19, 10, 9, 2),
(20, 10, 10, 3),
(21, 10, 11, 2),
(22, 10, 13, 1),
(23, 10, 14, 1),
(24, 11, 3, 1),
(25, 11, 7, 2),
(29, 13, 3, 1),
(32, 8, 3, 1),
(33, 8, 4, 1),
(34, 8, 9, 1),
(35, 8, 13, 1),
(36, 14, 12, 1),
(53, 15, 3, 1),
(54, 16, 3, 1),
(55, 17, 3, 1),
(56, 12, 4, 1),
(57, 12, 7, 1),
(58, 12, 10, 2),
(59, 12, 14, 1),
(60, 18, 3, 1),
(61, 18, 5, 1),
(62, 18, 7, 1),
(63, 18, 8, 1),
(64, 18, 10, 1),
(65, 18, 11, 1),
(66, 7, 3, 1),
(67, 7, 4, 2),
(68, 7, 6, 1),
(69, 7, 7, 2),
(70, 7, 8, 1),
(71, 7, 9, 1),
(72, 7, 11, 1),
(73, 7, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('Queued','Preparing','Ready','Completed') DEFAULT 'Queued',
  `sale_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `status`, `sale_date`) VALUES
(17, 21, 'Completed', '2025-07-17 20:25:55'),
(18, 21, 'Completed', '2025-07-17 20:27:00'),
(19, 21, 'Ready', '2025-07-17 20:35:00'),
(20, 21, 'Ready', '2025-07-18 00:16:47'),
(21, 21, 'Queued', '2025-07-18 00:19:58'),
(22, 21, 'Ready', '2025-07-18 00:20:40'),
(23, 21, 'Queued', '2025-07-18 00:21:03'),
(24, 21, 'Ready', '2025-07-18 00:23:34'),
(25, 21, 'Queued', '2025-07-18 00:23:45'),
(26, 21, 'Queued', '2025-07-18 00:26:07'),
(27, 21, 'Ready', '2025-07-18 00:32:52'),
(28, 21, 'Queued', '2025-07-18 00:34:02'),
(29, 21, 'Queued', '2025-07-18 00:35:00'),
(30, 21, 'Queued', '2025-07-18 00:35:03'),
(31, 21, 'Queued', '2025-07-18 00:37:51'),
(32, 21, 'Queued', '2025-07-18 00:39:01'),
(33, 21, 'Ready', '2025-07-18 00:39:15'),
(34, 21, 'Queued', '2025-07-18 00:40:46'),
(35, 21, 'Ready', '2025-07-18 00:42:09'),
(36, 21, 'Ready', '2025-07-18 00:44:45'),
(37, 21, 'Ready', '2025-07-18 01:51:51'),
(38, 21, 'Ready', '2025-07-18 01:52:17'),
(39, 22, 'Completed', '2025-07-18 01:55:44'),
(40, 22, 'Completed', '2025-07-18 02:06:33'),
(41, 22, 'Completed', '2025-07-18 16:42:06'),
(42, 22, 'Completed', '2025-07-18 16:57:59'),
(43, 22, 'Queued', '2025-07-18 16:59:21'),
(44, 22, 'Queued', '2025-07-18 16:59:43'),
(45, 22, 'Queued', '2025-07-18 16:59:46'),
(46, 22, 'Queued', '2025-07-18 17:00:07'),
(47, 22, 'Queued', '2025-07-18 17:00:09'),
(48, 22, 'Completed', '2025-07-18 17:01:10'),
(49, 22, 'Completed', '2025-07-18 17:03:42'),
(50, 22, 'Queued', '2025-07-18 17:04:11'),
(51, 22, 'Completed', '2025-07-18 17:04:55'),
(52, 22, 'Queued', '2025-07-18 17:05:19'),
(53, 22, 'Completed', '2025-07-18 17:06:16'),
(54, 20, 'Completed', '2025-07-18 18:05:05'),
(55, 20, 'Completed', '2025-07-18 18:25:50'),
(56, 20, 'Completed', '2025-07-18 18:30:53'),
(57, 20, 'Completed', '2025-07-18 18:33:14'),
(58, 20, 'Completed', '2025-07-18 18:36:44'),
(59, 20, 'Completed', '2025-07-18 18:52:29'),
(60, 20, 'Completed', '2025-07-31 17:08:03'),
(61, 22, 'Completed', '2025-07-31 17:10:22'),
(62, 22, 'Completed', '2025-07-31 17:10:44'),
(63, 20, 'Completed', '2025-07-31 17:33:23'),
(64, 20, 'Completed', '2025-07-31 19:00:48'),
(65, 20, 'Completed', '2025-07-31 19:13:50'),
(66, 22, 'Completed', '2025-07-31 19:20:02'),
(67, 22, 'Completed', '2025-07-31 19:20:36'),
(68, 22, 'Completed', '2025-07-31 19:23:13'),
(69, 20, 'Ready', '2025-07-31 19:55:22'),
(70, 20, 'Ready', '2025-07-31 20:18:17'),
(71, 20, 'Completed', '2025-07-31 20:19:28'),
(72, 20, 'Completed', '2025-07-31 22:03:41'),
(73, 20, 'Ready', '2025-07-31 22:45:41'),
(74, 22, 'Completed', '2025-08-01 08:14:00'),
(75, 20, 'Ready', '2025-08-01 08:48:06'),
(76, 22, 'Ready', '2025-08-01 08:52:52'),
(77, 22, 'Ready', '2025-08-01 09:10:56'),
(78, 23, 'Completed', '2025-08-15 02:37:59'),
(79, 21, 'Queued', '2025-08-15 07:57:47'),
(80, 21, 'Queued', '2025-08-15 07:59:25'),
(81, 21, 'Queued', '2025-08-15 15:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `order_queue`
--

CREATE TABLE `order_queue` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `menu_item_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_queue`
--

INSERT INTO `order_queue` (`id`, `order_id`, `menu_item_id`, `quantity`) VALUES
(17, 17, 7, 1),
(18, 18, 7, 1),
(19, 19, 7, 1),
(20, 20, 7, 1),
(21, 22, 7, 1),
(22, 24, 7, 1),
(23, 27, 7, 1),
(24, 33, 7, 1),
(25, 35, 7, 1),
(26, 36, 7, 1),
(27, 37, 7, 1),
(28, 38, 7, 2),
(29, 39, 7, 1),
(30, 40, 7, 1),
(31, 41, 8, 2),
(32, 42, 7, 1),
(33, 48, 7, 1),
(34, 49, 7, 1),
(35, 51, 7, 1),
(36, 53, 7, 1),
(37, 54, 7, 1),
(38, 55, 7, 1),
(39, 55, 8, 1),
(40, 56, 7, 1),
(41, 57, 7, 1),
(42, 57, 8, 1),
(43, 58, 7, 1),
(44, 59, 7, 2),
(45, 60, 8, 1),
(46, 61, 10, 1),
(47, 62, 10, 2),
(48, 63, 12, 1),
(49, 63, 11, 1),
(50, 64, 10, 2),
(51, 64, 7, 2),
(52, 65, 10, 1),
(53, 65, 13, 1),
(54, 66, 13, 1),
(55, 67, 11, 1),
(56, 68, 12, 1),
(57, 69, 10, 1),
(58, 70, 8, 2),
(59, 71, 12, 1),
(60, 72, 8, 1),
(61, 73, 8, 2),
(62, 74, 8, 1),
(63, 75, 18, 1),
(64, 76, 8, 1),
(65, 76, 10, 1),
(66, 77, 10, 1),
(67, 78, 8, 1),
(68, 79, 7, 1),
(69, 80, 8, 1),
(70, 81, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE `queue` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `status` enum('Queued','Preparing','Ready','Completed') DEFAULT 'Queued',
  `sale_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `table_category` enum('small','medium','large') NOT NULL,
  `table_number` int(11) NOT NULL,
  `reservation_datetime` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_name`, `phone`, `table_category`, `table_number`, `reservation_datetime`, `created_at`) VALUES
(30, 'Ischan', '09999630624', 'small', 0, '2025-08-22 01:00:00', '2025-08-21 08:17:37'),
(31, 'Ischan', '09999630624', 'small', 1, '2025-08-22 00:00:00', '2025-08-21 08:18:27'),
(32, 'Ischan', '09999630624', 'small', 2, '2025-08-22 00:00:00', '2025-08-21 08:18:56'),
(33, 'Ischan', '09999630624', 'small', 3, '2025-08-22 00:00:00', '2025-08-21 08:19:13'),
(34, 'Ischan', '09999630624', 'small', 4, '2025-08-22 00:00:00', '2025-08-21 08:19:29'),
(35, 'Ischan', '09999630624', 'small', 5, '2025-08-22 00:00:00', '2025-08-21 08:19:44'),
(36, 'Ischan', '09999630624', 'small', 1, '2025-08-21 12:00:00', '2025-08-21 08:31:21');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `sale_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `menu_item_id`, `quantity`, `total_price`, `sale_date`) VALUES
(31, 21, 7, 1, 150.00, '2025-07-17 20:25:55'),
(32, 21, 7, 1, 150.00, '2025-07-17 20:27:01'),
(33, 21, 7, 1, 150.00, '2025-07-17 20:35:00'),
(34, 21, 7, 1, 150.00, '2025-07-18 00:16:47'),
(35, 21, 7, 1, 150.00, '2025-07-18 00:20:40'),
(36, 21, 7, 1, 150.00, '2025-07-18 00:23:34'),
(37, 21, 7, 1, 150.00, '2025-07-18 00:32:52'),
(38, 21, 7, 1, 150.00, '2025-07-18 00:39:15'),
(39, 21, 7, 1, 150.00, '2025-07-18 00:42:09'),
(40, 21, 7, 1, 150.00, '2025-07-18 00:44:45'),
(41, 21, 7, 1, 160.00, '2025-07-18 01:51:51'),
(42, 21, 7, 2, 320.00, '2025-07-18 01:52:17'),
(43, 22, 7, 1, 160.00, '2025-07-18 01:55:44'),
(44, 22, 7, 1, 160.00, '2025-07-18 02:06:33'),
(45, 22, 8, 2, 100.00, '2025-07-18 16:42:06'),
(46, 22, 7, 1, 160.00, '2025-07-18 16:57:59'),
(47, 22, 7, 1, 160.00, '2025-07-18 17:01:10'),
(48, 22, 7, 1, 160.00, '2025-07-18 17:03:42'),
(49, 22, 7, 1, 160.00, '2025-07-18 17:04:55'),
(50, 22, 7, 1, 160.00, '2025-07-18 17:06:16'),
(51, 20, 7, 1, 160.00, '2025-07-18 18:05:05'),
(52, 20, 7, 1, 160.00, '2025-07-18 18:25:50'),
(53, 20, 8, 1, 50.00, '2025-07-18 18:25:50'),
(54, 20, 7, 1, 160.00, '2025-07-18 18:30:53'),
(55, 20, 7, 1, 160.00, '2025-07-18 18:33:14'),
(56, 20, 8, 1, 50.00, '2025-07-18 18:33:14'),
(57, 20, 7, 1, 160.00, '2025-07-18 18:36:44'),
(58, 20, 7, 2, 320.00, '2025-07-18 18:52:29'),
(59, 20, 8, 1, 50.00, '2025-07-31 17:08:03'),
(60, 22, 10, 1, 299.00, '2025-07-31 17:10:22'),
(61, 22, 10, 2, 598.00, '2025-07-31 17:10:44'),
(62, 20, 12, 1, 100.00, '2025-07-31 17:33:23'),
(63, 20, 11, 1, 100.00, '2025-07-31 17:33:23'),
(64, 20, 10, 2, 598.00, '2025-07-31 19:00:48'),
(65, 20, 7, 2, 320.00, '2025-07-31 19:00:48'),
(66, 20, 10, 1, 299.00, '2025-07-31 19:13:50'),
(67, 20, 13, 1, 75.00, '2025-07-31 19:13:50'),
(68, 22, 13, 1, 75.00, '2025-07-31 19:20:02'),
(69, 22, 11, 1, 100.00, '2025-07-31 19:20:36'),
(70, 22, 12, 1, 100.00, '2025-07-31 19:23:13'),
(71, 20, 10, 1, 299.00, '2025-07-31 19:55:22'),
(72, 20, 8, 2, 100.00, '2025-07-31 20:18:17'),
(73, 20, 12, 1, 100.00, '2025-07-31 20:19:28'),
(74, 20, 8, 1, 50.00, '2025-07-31 22:03:41'),
(75, 20, 8, 2, 100.00, '2025-07-31 22:45:41'),
(76, 22, 8, 1, 50.00, '2025-08-01 08:14:00'),
(77, 20, 18, 1, 150.00, '2025-08-01 08:48:06'),
(78, 22, 8, 1, 50.00, '2025-08-01 08:52:52'),
(79, 22, 10, 1, 299.00, '2025-08-01 08:52:52'),
(80, 22, 10, 1, 299.00, '2025-08-01 09:10:56'),
(81, 23, 8, 1, 50.00, '2025-08-15 02:37:59'),
(82, 21, 7, 1, 160.00, '2025-08-15 07:57:47'),
(83, 21, 8, 1, 50.00, '2025-08-15 07:59:25'),
(84, 21, 8, 1, 50.00, '2025-08-15 15:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','customer','kitchen','cashier') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`) VALUES
(20, 'admin', '$2y$10$flCBusiXu0.1OnBFzwRxJOuJup0C0MBhEePe/G609V3LajzFpxJTC', 'admin@example.com', 'admin'),
(21, 'cashier', '$2y$10$2QKyOnwioNKCbpMw1y.SXuxXVFne7ggFYeAzu/eIclt7rmb65.WL2', 'customer@example.com', 'cashier'),
(22, 'Staff', '$2b$12$mnXXyUpZpGLwHsR/lAWbJ.Ky5hzmwDRkUnSyDvXsiGO/.1qz7xA8y', 'kitchen@example.com', 'kitchen'),
(23, 'Arvie', '$2y$10$Mw1yhA2OEj2rC4PtYCyFj.1GHrQR09tXB2p4aTPNgpEs1lIznjeJy', 'arvie@gmail.com', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `menu_item_ingredients`
--
ALTER TABLE `menu_item_ingredients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_item_id` (`menu_item_id`),
  ADD KEY `ingredient_id` (`ingredient_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_queue`
--
ALTER TABLE `order_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `menu_item_id` (`menu_item_id`);

--
-- Indexes for table `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `menu_item_id` (`menu_item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=323;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `menu_item_ingredients`
--
ALTER TABLE `menu_item_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `order_queue`
--
ALTER TABLE `order_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `queue`
--
ALTER TABLE `queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
