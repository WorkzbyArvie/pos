<?php
session_start();
include 'includes/db.php';

$error = '';


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>The Burgis</title>
      <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous"/>

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body, html {
      height: 100%;
      overflow: hidden;
      font-family: 'Segoe UI', sans-serif;
    }

    .slideshow {
      position: fixed;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      z-index: -1;
    }

    .slideshow img {
      position: absolute;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0;
      animation: slideshow 20s infinite;
    }

    .slideshow img:nth-child(1) { animation-delay: 0s; }
    .slideshow img:nth-child(2) { animation-delay: 5s; }
    .slideshow img:nth-child(3) { animation-delay: 10s; }
    .slideshow img:nth-child(4) { animation-delay: 15s; }

    @keyframes slideshow {
      0% { opacity: 0; }
      5% { opacity: 1; }
      25% { opacity: 1; }
      30% { opacity: 0; }
      100% { opacity: 0; }
    }

    .content {
      position: relative;
      z-index: 1;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      color: white;
    }

    .content-box {
      background-color: rgba(66, 64, 64, 0.64);
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
      max-width: 400px;
      width: 90%;
    }

    .logo-box {
      border: 4px solid #2f6907;
      border-radius: 50%;
      padding: 20px;
      background-color: white;
      display: inline-block;
      cursor: pointer;
      margin-bottom: 20px;
    }

    .logo-icon {
      font-size: 60px;
      color: #2f6907;
    }

    .login-btn {
      padding: 12px 30px;
      background-color: #2f6907;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 18px;
      text-decoration: none;
      display: inline-block;
      margin-top: 20px;
    }

    .login-btn:hover {
      background-color: #ffc700;
    }

    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border-radius: 6px;
      border: none;
    }

    .login-btn {
      padding: 10px 20px;
      margin-top: 15px;
      background: #2f6907;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <div class="slideshow">
    <img src="img/5.png" alt="Slide 1">
    <img src="img/6.png" alt="Slide 2">
    <img src="img/7.png" alt="Slide 3">
    <img src="img/8.png" alt="Slide 4">
  </div>

  <div class="content">
    <div class="content-box">
      <div id="logoCircle" class="logo-box">
        <i class="fas fa-hamburger logo-icon"></i>
      </div>
      <h1 class="fw-bold mb-2">THE BURGIS</h1>
      <p class="mb-3">Fast. Tasty. Affordable.</p>

      <?php if ($error): ?>
        <p class="error"><?= $error ?></p>
      <?php endif; ?>

      <form method="POST">
        <a href="login.php" class="login-btn">LOGIN</a>
      </form>
    </div>
  </div>

  <script>
    document.getElementById("logoCircle").addEventListener("dblclick", function () {
      window.location.href = "login.php"; //dito ung secret login
    });
  </script>

</body>
</html>